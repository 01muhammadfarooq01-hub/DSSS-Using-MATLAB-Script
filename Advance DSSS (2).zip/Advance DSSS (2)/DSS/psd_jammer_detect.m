function [jammer_detected, spike_freqs_kHz, fig_handle] = psd_jammer_detect(received_signal, Rc, plot_flag)
% Welch PSD se received signal mein jammer spikes detect karta hai.
%
% INPUTS:
%   received_signal - chip-level received signal (row or column vector)
%   Rc              - chip rate in Hz (for frequency axis scaling)
%   plot_flag       - 1 = draw figure, 0 = detection only
%
% OUTPUTS:
%   jammer_detected  - 1 if jammer found, 0 otherwise
%   spike_freqs_kHz  - frequencies of detected spikes in kHz
%   fig_handle       - figure handle ([] if plot_flag=0)
%
% ALGORITHM:
%   Welch PSD -> noise floor = median(PSD) -> threshold = floor + 10 dB
%   Spikes above threshold = jammer tones
%
% COMPATIBILITY: MATLAB R2016a and above

    % force column for pwelch, then we handle orientation after
    received_signal = received_signal(:);

    % --- Welch window sizing ---
    win_len = 2^floor(log2(length(received_signal) / 8));
    win_len = max(win_len, 64);
    win_len = min(win_len, 4096);
    overlap = round(win_len / 2);

    % --- Welch PSD --- pwelch returns column vectors
    [Pxx, F_Hz] = pwelch(received_signal, hamming(win_len), overlap, win_len, Rc);

    % Force everything to row vectors from here on
    Pxx   = Pxx(:).';
    F_Hz  = F_Hz(:).';
    F_kHz = F_Hz / 1000;

    Pxx_dB = 10 * log10(Pxx + eps);

    % --- Detection ---
    noise_floor_dB   = median(Pxx_dB);
    detection_thr_dB = noise_floor_dB + 10;

    spike_mask      = Pxx_dB > detection_thr_dB;   % row logical
    spike_freqs_kHz = F_kHz(spike_mask);            % row vector
    jammer_detected = any(spike_mask);

    if jammer_detected
        jammer_SNR_dB = max(Pxx_dB(spike_mask)) - noise_floor_dB;
    else
        jammer_SNR_dB = 0;
    end

    % --- Console ---
    fprintf('  Welch PSD Window      : %d points  (Delta_f = %.2f kHz)\n', ...
        win_len, Rc/win_len/1000);
    fprintf('  Noise Floor (median)  : %.2f dB\n', noise_floor_dB);
    fprintf('  Detection Threshold   : %.2f dB  (+10 dB above floor)\n', detection_thr_dB);

    if jammer_detected
        fprintf('  [!] JAMMER DETECTED   : %d spike(s) found\n', sum(spike_mask));
        fprintf('  Jammer Frequencies    : ');
        uniq_f = unique(round(spike_freqs_kHz * 10) / 10);
        fprintf('%.1f kHz  ', uniq_f(1:min(5,end)));
        fprintf('\n');
        fprintf('  Spike above floor     : %.1f dB\n', jammer_SNR_dB);
    else
        fprintf('  [OK] No jammer detected above threshold.\n');
    end

    % --- Plot ---
    fig_handle = [];
    if ~plot_flag
        return;
    end

    fig_handle = figure('Name', 'Fig 8: Welch PSD - Jammer Detection', ...
                        'NumberTitle', 'off', 'Position', [180 100 1000 600]);
    set(gcf, 'Color', 'w');

    % ---- Subplot 1: Full PSD ----
    subplot(2,1,1);
    plot(F_kHz, Pxx_dB, 'Color', [0.1 0.5 0.1], 'LineWidth', 1.5);
    hold on;

    y_lo = min(Pxx_dB) - 5;
    y_hi = max(Pxx_dB) + 8;
    ylim([y_lo, y_hi]);
    xlim([0, Rc/2/1000]);
    xl = xlim;

    line(xl, [noise_floor_dB noise_floor_dB], ...
        'Color','b','LineStyle','--','LineWidth',1.5);
    text(xl(2)*0.02, noise_floor_dB+0.5, ...
        sprintf('Noise Floor (%.1f dB)', noise_floor_dB), ...
        'Color','b','FontSize',8,'FontWeight','bold');

    line(xl, [detection_thr_dB detection_thr_dB], ...
        'Color','r','LineStyle','--','LineWidth',2);
    text(xl(2)*0.02, detection_thr_dB+0.5, ...
        sprintf('Detect Thr (%.1f dB)', detection_thr_dB), ...
        'Color','r','FontSize',8,'FontWeight','bold');

    if jammer_detected
        plot(spike_freqs_kHz, Pxx_dB(spike_mask), ...
            'rv', 'MarkerSize',10, 'MarkerFaceColor','r', 'LineStyle','none');
        title(sprintf('[!] Jammer DETECTED at %.1f kHz  |  %.1f dB above floor', ...
            spike_freqs_kHz(1), jammer_SNR_dB), 'Color','r');
        legend('PSD','Noise Floor','Detect Threshold','Jammer Spike','Location','northeast');
    else
        title('[OK] No Jammer Detected', 'Color',[0 0.5 0]);
        legend('PSD','Noise Floor','Detect Threshold','Location','northeast');
    end

    grid on;
    xlabel('Frequency (kHz)'); ylabel('PSD (dB/Hz)');

    % ---- Subplot 2: Zoomed ----
    subplot(2,1,2);

    if jammer_detected
        zoom_c  = spike_freqs_kHz(1);
        zoom_bw = Rc / 1000 * 0.05;
        f_lo    = max(0, zoom_c - zoom_bw);
        f_hi    = zoom_c + zoom_bw;

        % All row vectors guaranteed above — safe indexing
        zoom_f_mask = F_kHz >= f_lo & F_kHz <= f_hi;

        if any(zoom_f_mask)
            plot(F_kHz(zoom_f_mask), Pxx_dB(zoom_f_mask), ...
                'Color',[0.7 0 0], 'LineWidth',2);
        else
            plot(F_kHz, Pxx_dB, 'Color',[0.7 0 0], 'LineWidth',2);
            f_lo = F_kHz(1); f_hi = F_kHz(end);
        end
        hold on;

        xl2 = [f_lo, f_hi];
        y2lo = min(Pxx_dB) - 5;
        y2hi = max(Pxx_dB) + 8;
        ylim([y2lo, y2hi]);
        line(xl2,[noise_floor_dB noise_floor_dB],'Color','b','LineStyle','--','LineWidth',1.5);
        line(xl2,[detection_thr_dB detection_thr_dB],'Color','r','LineStyle','--','LineWidth',1.5);

        % Plot spikes that fall inside zoom window
        in_zoom = spike_freqs_kHz >= f_lo & spike_freqs_kHz <= f_hi;
        in_psd  = spike_mask & zoom_f_mask;   % both are row logical — safe
        if any(in_zoom) && any(in_psd)
            plot(spike_freqs_kHz(in_zoom), Pxx_dB(in_psd), ...
                'rv','MarkerSize',10,'MarkerFaceColor','r','LineStyle','none');
        end

        xlim(xl2);
        title(sprintf('Zoomed: %.1f kHz +/- %.1f kHz', zoom_c, zoom_bw));
    else
        plot(F_kHz, Pxx_dB, 'Color',[0.2 0.6 0.8], 'LineWidth',1.5);
        hold on;
        xl3 = [F_kHz(1), F_kHz(end)];
        line(xl3,[noise_floor_dB noise_floor_dB],'Color','b','LineStyle','--','LineWidth',1.5);
        line(xl3,[detection_thr_dB detection_thr_dB],'Color','r','LineStyle','--','LineWidth',1.5);
        title('Full Spectrum - No Spikes Found');
    end

    grid on;
    xlabel('Frequency (kHz)'); ylabel('PSD (dB/Hz)');

    annotation('textbox',[0.72 0.08 0.25 0.14], ...
        'String', sprintf('Window: %d pts\nDelta_f: %.2f kHz\nFloor: %.1f dB\nThr: %.1f dB', ...
            win_len, Rc/win_len/1000, noise_floor_dB, detection_thr_dB), ...
        'FitBoxToText','on','BackgroundColor','white','EdgeColor','black','FontSize',9);

end
