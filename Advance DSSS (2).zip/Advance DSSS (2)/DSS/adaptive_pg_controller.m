function [fp_opt, BER_adaptive_curve, PG_trace] = adaptive_pg_controller(...
            m_polar_seg, pn_code_full, DSSS_seg, jammer_seg, snr_range, ...
            fp_init, fp_min, fp_max, BER_thresh_high, BER_thresh_low)
%% ========================================================================
%% FUNCTION: adaptive_pg_controller
%% ========================================================================
% PURPOSE : BER feedback loop use karke Processing Gain ko dynamically
%           adjust karta hai. Agar BER zyada ho to PG double, agar BER kam
%           ho to PG half. Optimal PG find karta hai aur BER curve return
%           karta hai.
%
% INPUTS:
%   m_polar_seg      - Short BPSK segment (row vector) for quick BER testing
%   pn_code_full     - Full PN code (row vector); trimmed internally
%   DSSS_seg         - DSSS chip-level segment (row vector)
%   jammer_seg       - Jammer chip-level segment (row vector)
%   snr_range        - SNR values to test (dB vector)
%   fp_init          - Initial processing gain
%   fp_min           - Minimum allowed PG  (hardware constraint)
%   fp_max           - Maximum allowed PG  (hardware constraint)
%   BER_thresh_high  - If BER > this  => increase PG
%   BER_thresh_low   - If BER < this  => decrease PG (bandwidth recovery)
%
% OUTPUTS:
%   fp_opt            - Optimal (final converged) processing gain
%   BER_adaptive_curve- BER vs SNR for adaptive PG system
%   PG_trace          - PG value used at each SNR point
%
% ALGORITHM (BER Feedback Loop):
%   For each SNR:
%     1. Start with fp_current
%     2. Transmit DSSS segment through channel
%     3. Despread and demodulate -> BER_current
%     4. If BER_current > BER_thresh_high AND fp < fp_max: fp = fp * 2  (double)
%     5. If BER_current < BER_thresh_low  AND fp > fp_min: fp = fp / 2  (halve)
%     6. Else: fp unchanged
%     7. Record BER and PG used
%   fp_opt = PG at end of loop (converged at highest SNR)
%
% NOTE:
%   Fast mode: uses short segment (~1000 bits) for speed.
%   Full demodulation chain NOT run — just despreading + integrate-and-dump.
%   This reflects hardware-friendly integrate-and-dump architecture.
%% ========================================================================

    N_snr              = length(snr_range);
    BER_adaptive_curve = zeros(1, N_snr);
    PG_trace           = zeros(1, N_snr);

    bits_seg     = double(m_polar_seg < 0);   % Original bits (0/1) from bipolar
    N_bits_seg   = length(m_polar_seg);
    fp_current   = fp_init;

    fprintf('  [Adaptive PG] BER Feedback Loop running (%d SNR points)...\n', N_snr);

    for k = 1:N_snr
        snr_k = snr_range(k);

        %% --- Re-spread with current fp ---
        % Use current PG to spread the segment
        pn_k_len = N_bits_seg * fp_current;
        pn_k_len = min(pn_k_len, length(pn_code_full));  % Safety clamp

        if pn_k_len > length(pn_code_full)
            % Not enough PN chips — repeat cyclically
            repeats = ceil(pn_k_len / length(pn_code_full));
            pn_use  = repmat(pn_code_full, 1, repeats);
            pn_use  = pn_use(1:pn_k_len);
        else
            pn_use  = pn_code_full(1:pn_k_len);
        end

        me_k   = repelem(m_polar_seg, fp_current);
        me_k   = me_k(:).';
        pn_use = pn_use(:).';

        % Align lengths
        min_len_k = min(length(me_k), length(pn_use));
        dsss_k  = me_k(1:min_len_k) .* pn_use(1:min_len_k);

        % Jammer for this length
        jam_k = jammer_seg(1:min(length(jammer_seg), length(dsss_k)));
        jam_k = [jam_k, zeros(1, length(dsss_k) - length(jam_k))];

        %% --- AWGN + Jammer ---
        rx_chips = awgn_channel(dsss_k + jam_k, snr_k);
        rx_chips = rx_chips(:).';

        %% --- Integrate and Dump Despreading ---
        % Despread: rx * pn
        pn_rx   = pn_use(1:length(rx_chips));
        desp    = rx_chips .* pn_rx;
        N_bits_rx = floor(length(desp) / fp_current);
        desp_mat  = reshape(desp(1:N_bits_rx*fp_current), fp_current, N_bits_rx);
        integrated = sum(desp_mat, 1);   % Sum fp chips => bit decision variable

        %% --- BPSK Decision ---
        bits_decided = double(integrated < 0);   % -1 -> 1, +1 -> 0

        %% --- BER ---
        clen = min(length(bits_seg), length(bits_decided));
        BER_current = sum(bits_seg(1:clen) ~= bits_decided(1:clen)) / clen;

        %% --- Adaptive PG Decision ---
        fp_old = fp_current;

        if BER_current > BER_thresh_high && fp_current < fp_max
            % BER too high -> increase PG (double it, cap at fp_max)
            fp_current = min(fp_current * 2, fp_max);

        elseif BER_current < BER_thresh_low && fp_current > fp_min
            % BER good -> reduce PG to save bandwidth (halve it, floor at fp_min)
            fp_current = max(floor(fp_current / 2), fp_min);
        end
        % else: fp unchanged (BER in acceptable zone)

        BER_adaptive_curve(k) = BER_current;
        PG_trace(k)           = fp_old;   % PG actually used for this SNR

        fprintf('    SNR=%+3d dB | PG=%3d | BER=%.5f | PG_next=%3d\n', ...
            snr_k, fp_old, BER_current, fp_current);
    end

    fp_opt = fp_current;   % Converged PG (at highest SNR)

    fprintf('  [Adaptive PG] Converged PG = %d (JM = %.1f dB)\n', ...
        fp_opt, 10*log10(fp_opt));
end
