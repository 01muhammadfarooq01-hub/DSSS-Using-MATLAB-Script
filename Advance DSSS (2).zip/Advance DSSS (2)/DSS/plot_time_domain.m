function plot_time_domain(bpsk_waveform, pn_waveform, dsss_waveform, t_waveform, ...
                          bit_rate, chip_rate, fp, total_time, total_bits, ...
                          time_to_plot, sps)
%% ========================================================================
%% FUNCTION: plot_time_domain
%% ========================================================================
% PURPOSE  : BPSK, PN sequence, aur DSSS signal ko time domain mein plot karta hai
%
% X-AXIS   : 0 to 10 ms fixed (taake waveform clearly visible ho)
%
% INPUTS:
%   bpsk_waveform  - BPSK signal waveform (rectangular pulse expanded)
%   pn_waveform    - PN code waveform (chip-level, sps se expand kiya hua)
%   dsss_waveform  - DSSS spread signal waveform
%   t_waveform     - Time vector (seconds, BPSK sampling rate)
%   bit_rate       - Data bit rate (bps)
%   chip_rate      - PN chip rate (bps)
%   fp             - Processing gain (spreading factor)
%   total_time     - Total signal duration (seconds)
%   total_bits     - Total number of bits
%   time_to_plot   - Plot window (seconds) — used for sample count only
%   sps            - Samples per symbol
%
% COMPATIBILITY: MATLAB R2016a and above
%% ========================================================================

    %% --- Vector Orientation Fix ---
    bpsk_waveform = bpsk_waveform(:).';
    pn_waveform   = pn_waveform(:).';
    dsss_waveform = dsss_waveform(:).';
    t_waveform    = t_waveform(:).';

    %% --- Fixed X-axis: 0 to 10 ms ---
    x_end_ms = 1.5;   % Always show exactly 10 ms so waveforms are clearly visible

    %% --- How many samples fit in 10 ms ---
    Fs_bpsk  = bit_rate * sps;           % BPSK waveform sampling rate
    Fs_chip  = chip_rate * sps;          % Chip waveform sampling rate

    n_bpsk   = min(round(x_end_ms * 1e-3 * Fs_bpsk), length(bpsk_waveform));
    n_chip   = min(round(x_end_ms * 1e-3 * Fs_chip),  length(pn_waveform));
    n_chip   = min(n_chip, length(dsss_waveform));
    n_bpsk   = min(n_bpsk, length(t_waveform));
    n_chip   = min(n_chip, length(t_waveform));

    figure('Name', 'Fig 1: TX Time Domain (BPSK, PN, DSSS)', ...
           'NumberTitle', 'off', 'Position', [100 100 900 700]);
    set(gcf, 'Color', 'w');

    %% --- Subplot 1: BPSK Signal ---
    subplot(3,1,1);
    plot(t_waveform(1:n_bpsk)*1e3, bpsk_waveform(1:n_bpsk), ...
        'LineWidth', 1.5, 'Color', [0.2 0.4 0.8]);
    grid on;
    ylim([-1.5 1.5]);
    xlim([0, x_end_ms]);
    xlabel('Time (ms)'); ylabel('Amplitude');
    title(sprintf('BPSK Baseband Signal | Bit Rate: %.1f kbps | Showing 0-10 ms', ...
        bit_rate/1000));
    text(0.2, 1.25, sprintf('Total: %.3f sec | %d bits', total_time, total_bits), ...
        'FontSize', 9, 'FontWeight', 'bold');

    %% --- Subplot 2: PN Sequence ---
    subplot(3,1,2);
    plot(t_waveform(1:n_chip)*1e3, pn_waveform(1:n_chip), ...
        'LineWidth', 1.2, 'Color', [0.8 0.2 0.2]);
    grid on;
    ylim([-1.5 1.5]);
    xlim([0, x_end_ms]);
    xlabel('Time (ms)'); ylabel('Amplitude');
    title(sprintf('PN Sequence (LFSR m-sequence) | Chip Rate: %.4f Mcps | PG: %d', ...
        chip_rate/1e6, fp));

    %% --- Subplot 3: DSSS Spread Signal ---
    subplot(3,1,3);
    plot(t_waveform(1:n_chip)*1e3, dsss_waveform(1:n_chip), ...
        'LineWidth', 1.2, 'Color', [0.2 0.6 0.2]);
    grid on;
    ylim([-1.5 1.5]);
    xlim([0, x_end_ms]);
    xlabel('Time (ms)'); ylabel('Amplitude');
    title(sprintf('DSSS Spread Signal (BPSK x PN) | Showing 0-10 ms'));

end
