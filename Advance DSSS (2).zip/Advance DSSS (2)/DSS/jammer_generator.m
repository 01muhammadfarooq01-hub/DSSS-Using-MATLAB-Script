function jammer = jammer_generator(N_chips, jammer_type, jparams)
%% ========================================================================
%% FUNCTION: jammer_generator
%% ========================================================================
% PURPOSE : Selectable jammer signal generate karta hai chip level pe.
%           3 types support karta hai: CW, Swept (chirp), Multitone.
%
% INPUTS:
%   N_chips      - Total chips (length of output jammer signal)
%   jammer_type  - String: 'CW' | 'swept' | 'multitone'
%   jparams      - Struct with jammer parameters:
%
%   For ALL types:
%     jparams.Aj          - Jammer amplitude (absolute, e.g. 0.85)
%
%   For 'CW' (Narrowband Continuous Wave):
%     jparams.fj_norm     - Normalized jammer freq (0..1, fraction of Rc)
%                           Actual freq = fj_norm * Rc
%                           Formula: fj_norm = fj_Hz / Rc
%
%   For 'swept' (Linear Frequency Sweep / Chirp):
%     jparams.f_start_norm - Start freq (normalized, 0..1)
%     jparams.f_stop_norm  - Stop  freq (normalized, 0..1)
%     jparams.T_sweep      - Sweep period (sec); chirp repeats every T_sweep
%                            Formula: phi(n) = 2pi*(f_s*n + (f_e-f_s)*n^2/(2*Rc*T_sweep))
%
%   For 'multitone' (Multiple CW jammers):
%     jparams.f_tones_norm - Vector of normalized frequencies [f1, f2, ...]
%                            Power split equally: each tone = Aj/N_tones
%
% OUTPUT:
%   jammer  - Row vector, length N_chips, chip-level jammer signal
%
% FORMULAS:
%   CW         : j(n) = Aj * sin(2*pi*fj*n)
%   Swept      : j(n) = Aj * sin(phi(n))  where phi = integral of 2*pi*f(n)
%                f(n) = f_start + (f_stop-f_start)*n/(Rc*T_sweep)  [linear chirp]
%   Multitone  : j(n) = sum_k [ (Aj/K) * sin(2*pi*f_k*n) ]
%% ========================================================================

    n = (0:N_chips-1).';   % Sample index column vector

    switch lower(strtrim(jammer_type))

        %% ----------------------------------------------------------
        case 'cw'
        %% Narrowband CW Jammer
        % Most common anti-BPSK jammer. DSSS despreads it to noise floor.
        % j(n) = Aj * sin(2*pi * fj_norm * n)
        %   fj_norm = fj_Hz / Rc  (normalized so 1 chip = 1 cycle at Rc)
            jammer = jparams.Aj * sin(2*pi * jparams.fj_norm * n);

        %% ----------------------------------------------------------
        case 'swept'
        %% Swept / Linear Chirp Jammer
        % Sweeps from f_start to f_stop over T_sweep seconds, then repeats.
        % More effective than CW because covers wider band.
        %
        % Instantaneous (normalized) freq: f(n) = f_s + (f_e-f_s)*mod(n,N_sw)/N_sw
        % Instantaneous phase (integral): phi(n) = 2*pi * [f_s*r + (f_e-f_s)*r^2/2]
        %   where r = mod(n, N_sw) / N_sw   (sawtooth ramp 0->1 each sweep)
        % This avoids phase discontinuities between sweeps.

            f_s  = jparams.f_start_norm;
            f_e  = jparams.f_stop_norm;

            % Sweep length in chips
            if isfield(jparams, 'T_sweep') && ~isempty(jparams.T_sweep)
                % T_sweep provided in seconds -> convert to chips
                % (Rc is not passed here; user sets it via fj_norm scale)
                % Use T_sweep as fraction of total signal for simplicity
                N_sw = round(jparams.T_sweep * N_chips);
            else
                N_sw = N_chips;   % Single sweep over entire signal
            end
            N_sw = max(N_sw, 2);   % Safety minimum

            r = mod(n, N_sw) / N_sw;   % Normalized ramp 0->1 (repeats)
            phase = 2*pi * (f_s * r + (f_e - f_s) * r.^2 / 2) .* N_sw;
            jammer = jparams.Aj * sin(phase);

        %% ----------------------------------------------------------
        case 'multitone'
        %% Multitone Jammer (sum of CW jammers at multiple freqs)
        % Power distributed equally among K tones.
        % j(n) = (Aj/K) * sum_k sin(2*pi*f_k*n)
        % Most effective when tones spread across BPSK bandwidth.

            f_tones = jparams.f_tones_norm(:);   % Column vector of freqs
            K       = length(f_tones);
            jammer  = zeros(N_chips, 1);

            for k = 1:K
                jammer = jammer + sin(2*pi * f_tones(k) * n);
            end
            jammer = (jparams.Aj / K) * jammer;   % Normalize total power

        otherwise
            error('jammer_generator: Unknown type "%s". Use ''CW'', ''swept'', or ''multitone''.', ...
                jammer_type);
    end

    %% Final output: row vector, guaranteed
    jammer = jammer(:).';

    %% Console info
    jammer_power = mean(jammer.^2);
    fprintf('  Jammer Type           : %s\n', upper(strtrim(jammer_type)));
    fprintf('  Jammer Chips          : %d\n', N_chips);
    fprintf('  Jammer Power          : %.4f\n', jammer_power);
    fprintf('  JSR (est)             : %.1f dB\n', 10*log10(jammer_power));

end
