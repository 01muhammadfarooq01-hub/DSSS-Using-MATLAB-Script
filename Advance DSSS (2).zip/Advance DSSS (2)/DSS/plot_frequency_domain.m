function plot_frequency_domain(bpsk_waveform, DSSS_chips, Fs_pulse, ...
                                Rb, Rc, fp, total_time, rolloff)
%% ========================================================================
%% FUNCTION: plot_frequency_domain
%% ========================================================================
% PURPOSE : BPSK aur DSSS signal ka power spectrum plot karta hai.
%
% INPUTS:
%   bpsk_waveform  - BPSK waveform (m_polar ko sps se repelem kiya hua)
%   DSSS_chips     - DSSS chip-level signal (bipolar, 1 sample/chip)
%   Fs_pulse       - BPSK waveform sampling rate = Rb * sps  (Hz)
%   Rb             - Bit rate (bps)
%   Rc             - Chip rate (bps) = Rb * fp
%   fp             - Processing gain
%   total_time     - Signal duration (seconds)
%   rolloff        - [OPTIONAL] RRC roll-off factor alpha (default = 0.35)
%                    BW = (1+alpha)*R  formula use hoti hai
%
% BACKWARD COMPATIBLE: Old files (7 args) bhi chalenge — rolloff=0.35 default.
%
% COMPATIBILITY: MATLAB R2016a and above.
%% ========================================================================

    %% --- Optional rolloff argument (backward compatible) ---
    if nargin < 8
        rolloff = 0.35;   % Default roll-off factor (practical standard)
    end

    %% --- Vector Orientation Fix ---
    bpsk_waveform = bpsk_waveform(:).';
    DSSS_chips    = DSSS_chips(:).';

    %% --- Bandwidth Calculation ---
    % RRC formula: BW = (1 + alpha) * R
    bw_bpsk_kHz = (1 + rolloff) * Rb / 1000;
    bw_dsss_kHz = (1 + rolloff) * Rc / 1000;

    % First sinc null (for null marker — value from formula: null = R)
    null_bpsk_kHz = Rb / 1000;
    null_dsss_kHz = Rc / 1000;

    %% --- DSSS Oversample for FFT ---
    sps_spec = 10;
    dsss_os  = repelem(DSSS_chips, sps_spec);
    Fs_dsss  = Rc * sps_spec;

    figure('Name', 'Fig 3: Spectrum Analysis - DSSS Spreading Effect', ...
           'NumberTitle', 'off', 'Position', [150 50 1000 700]);
    set(gcf, 'Color', 'w');

    %% -------------------------------------------------------
    %% Subplot 1: BPSK Spectrum
    %% -------------------------------------------------------
    subplot(2,1,1);

    window_bpsk   = hamming(length(bpsk_waveform))';
    bpsk_windowed = bpsk_waveform .* window_bpsk;

    NFFT    = 2^nextpow2(length(bpsk_windowed));
    Y_bpsk  = fft(bpsk_windowed, NFFT);
    P2_bpsk = abs(Y_bpsk / NFFT);
    P1_bpsk = P2_bpsk(1:NFFT/2+1);
    P1_bpsk(2:end-1) = 2 * P1_bpsk(2:end-1);

    f_bpsk = (0:(NFFT/2)) * (Fs_pulse / NFFT) / 1000;   % kHz

    plot(f_bpsk, 10*log10(P1_bpsk/max(P1_bpsk)), ...
         'LineWidth', 1.8, 'Color', [0.2 0.4 0.8]);
    grid on; hold on;

    % Y-axis limits first so lines span correctly
    y1 = ylim;
    xlim([0, bw_bpsk_kHz * 1.3]);

    % Null line — line() instead of yline() for R2016 compat
    line([null_bpsk_kHz null_bpsk_kHz], y1, ...
         'Color', 'r', 'LineStyle', '--', 'LineWidth', 2);
    text(null_bpsk_kHz * 1.04, y1(2) - 3, ...
         sprintf('Null @ %.1f kHz', null_bpsk_kHz), ...
         'Color', 'r', 'FontWeight', 'bold', 'FontSize', 8);

    % BW line
    line([bw_bpsk_kHz bw_bpsk_kHz], y1, ...
         'Color', [0 0.6 0], 'LineStyle', '--', 'LineWidth', 1.5);
    text(bw_bpsk_kHz * 1.04, y1(1) + 3, ...
         sprintf('BW: %.1f kHz', bw_bpsk_kHz), ...
         'Color', [0 0.6 0], 'FontWeight', 'bold', 'FontSize', 8);

    title('BPSK Power Spectrum (Before Spreading)');
    xlabel('Frequency (kHz)'); ylabel('Normalized Power (dB)');

    info_str1 = sprintf('BPSK Signal:\nBit Rate: %.1f kbps\nBW=(1+%.2f)*Rb\n= %.1f kHz\nDuration: %.2f sec', ...
                        Rb/1000, rolloff, bw_bpsk_kHz, total_time);
    annotation('textbox', [0.15, 0.75, 0.15, 0.13], 'String', info_str1, ...
               'FitBoxToText', 'on', 'BackgroundColor', 'white', ...
               'EdgeColor', 'black', 'FontSize', 9);

    %% -------------------------------------------------------
    %% Subplot 2: DSSS Spectrum
    %% -------------------------------------------------------
    subplot(2,1,2);

    window_dsss   = hamming(length(dsss_os))';
    dsss_windowed = dsss_os .* window_dsss;

    NFFT_d  = 2^nextpow2(length(dsss_windowed));
    Y_dsss  = fft(dsss_windowed, NFFT_d);
    P2_dsss = abs(Y_dsss / NFFT_d);
    P1_dsss = P2_dsss(1:NFFT_d/2+1);
    P1_dsss(2:end-1) = 2 * P1_dsss(2:end-1);

    f_dsss = (0:(NFFT_d/2)) * (Fs_dsss / NFFT_d) / 1000;   % kHz

    plot(f_dsss, 10*log10(P1_dsss/max(P1_dsss)), ...
         'LineWidth', 1.8, 'Color', [0.2 0.6 0.2]);
    grid on; hold on;

    y2 = ylim;
    xlim([0, bw_dsss_kHz * 1.3]);

    line([null_dsss_kHz null_dsss_kHz], y2, ...
         'Color', 'r', 'LineStyle', '--', 'LineWidth', 2);
    text(null_dsss_kHz * 1.04, y2(2) - 3, ...
         sprintf('Null @ %.1f kHz', null_dsss_kHz), ...
         'Color', 'r', 'FontWeight', 'bold', 'FontSize', 8);

    line([bw_dsss_kHz bw_dsss_kHz], y2, ...
         'Color', [0 0.6 0], 'LineStyle', '--', 'LineWidth', 1.5);
    text(bw_dsss_kHz * 1.04, y2(1) + 3, ...
         sprintf('BW: %.1f kHz', bw_dsss_kHz), ...
         'Color', [0 0.6 0], 'FontWeight', 'bold', 'FontSize', 8);

    title('DSSS Power Spectrum (After Spreading) - Spectrum Spread');
    xlabel('Frequency (kHz)'); ylabel('Normalized Power (dB)');

    info_str2 = sprintf('DSSS Signal:\nChip Rate: %.2f Mcps\nBW=(1+%.2f)*Rc\n= %.1f kHz\nPG: %d | Exp: %dx', ...
                        Rc/1e6, rolloff, bw_dsss_kHz, fp, fp);
    annotation('textbox', [0.15, 0.25, 0.15, 0.14], 'String', info_str2, ...
               'FitBoxToText', 'on', 'BackgroundColor', 'white', ...
               'EdgeColor', 'black', 'FontSize', 9);

end
