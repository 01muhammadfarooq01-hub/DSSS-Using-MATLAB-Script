function p = dsss_params(Fs_audio)
% Computes all DSSS system parameters from fundamental telecom formulas.
% Only user-settable design choices are at the top — everything else
% is derived automatically from those inputs.
%
% INPUT:  Fs_audio — audio file sampling rate in Hz (from audioread)
% OUTPUT: p        — struct containing all system parameters

% =========================================================================
% USER-SETTABLE DESIGN INPUTS
% Change these to reconfigure the whole system
% =========================================================================
p.n_pcm        = 8;    % PCM bit depth
p.m_bch        = 4;    % BCH generator polynomial order  => N = 2^m - 1
p.t_bch        = 1;    % BCH error correction (errors correctable per codeword)
p.burst_len    = 5;    % Expected burst error span (chips)  => sets interleaver
p.JM_target_dB = 10;   % Target jamming margin (dB)  => sets processing gain
p.oversampling = 8;    % Waveform oversampling factor (>= 8 for clean RRC)
p.EbN0_dB      = 7;    % Operating Eb/N0 (dB)
p.T_audio      = 1.0;  % Audio segment duration (sec)
p.N_plot_bits  = 50;   % Number of bits to show in time-domain plots

% =========================================================================
% DERIVED PARAMETERS — do not edit below this line
% =========================================================================

% --- PCM ---
% Number of quantization levels: L = 2^n
p.L = 2^p.n_pcm;

% Audio samples to use: Ns = T_audio * Fs
p.Ns_audio = round(p.T_audio * Fs_audio);

% --- BCH Channel Code ---
% Codeword length:  N = 2^m - 1
% Data bits:        K = N - m*t
% Code rate:        R = K/N
p.N_bch = 2^p.m_bch - 1;
p.K_bch = p.N_bch - p.m_bch * p.t_bch;
p.R_bch = p.K_bch / p.N_bch;

% --- Interleaver ---
% Depth set to 4x burst length so matrix interleaver fully breaks burst errors
p.intDepth = 4 * p.burst_len;

% --- Bit Rate ---
% PCM stream rate: each audio sample produces n_pcm bits
% Rb = Fs * n_pcm
p.Rb    = Fs_audio * p.n_pcm;
p.T_bit = 1 / p.Rb;

% --- Oversampling / Samples Per Symbol ---
% sps = oversampling factor (Nyquist minimum = 2, RRC needs >= 8)
% Fs_pulse = waveform sampling rate
p.sps      = p.oversampling;
p.Fs_pulse = p.oversampling * p.Rb;

% --- Processing Gain ---
% From target jamming margin:  JM_dB = 10*log10(PG)
%   =>  PG = 10^(JM_dB/10)
p.fp = ceil(10^(p.JM_target_dB / 10));

% --- Chip Rate ---
% Rc = Rb * PG
p.Rc     = p.Rb * p.fp;
p.T_chip = 1 / p.Rc;

% --- PN Sequence (LFSR) ---
% Minimum LFSR register length m such that 2^m - 1 >= fp
% (ensures at least one full m-sequence period per bit interval)
p.m_pn     = ceil(log2(p.fp + 1));
p.pn_period = 2^p.m_pn - 1;

% --- RRC Pulse Shaping Filter ---
% Target bandwidth = Rc * 1.2  (20% spectral headroom)
% RRC rolloff:  alpha = BW_target/Rc - 1  =>  BW = (1+alpha)*Rc
% Clamp to valid range [0.2, 0.5]
% Filter span:  rrc_span = ceil(6/alpha)  covers >99% of ISI
BW_target  = p.Rc * 1.2;
p.rolloff  = (BW_target / p.Rc) - 1;
p.rolloff  = min(max(p.rolloff, 0.2), 0.5);
p.rrc_span = ceil(6 / p.rolloff);

% --- Signal Bandwidth (RRC formula) ---
% BW = (1 + alpha) * R
p.BW_bpsk_kHz = (1 + p.rolloff) * p.Rb / 1000;
p.BW_dsss_kHz = (1 + p.rolloff) * p.Rc / 1000;

% --- SNR Adjustment for BCH Coded System ---
% Coding reduces effective SNR per info bit by code rate
% SNR_adj = Eb/N0 + 10*log10(K/N)
p.snr_adj = p.EbN0_dB + 10*log10(p.R_bch);

% --- BER vs SNR Test Range ---
p.snr_range = -5:2:20;

end
