% =========================================================================
% DSSS-Based Anti-Jamming Communication System
% Experiment 1 - Part 4: Full chain with adaptive jammer suppression
%
% System Block Diagram:
%   Audio In -> PCM -> BCH Enc -> Scramble -> Interleave ->
%   BPSK Mod -> DSSS Spread -> AWGN + Jammer ->
%   Despread -> BPSK Demod -> Deinterleave -> Descramble ->
%   BCH Dec -> Audio Out
%
% All system parameters are derived from fundamental formulas.
% No hardcoded values except user-settable inputs in Section 1.
%
% Output figures:
%   Fig 1 - Transmitted signals: BPSK, PN sequence, DSSS
%   Fig 2 - RRC pulse shaped waveforms
%   Fig 3 - Power spectrum: BPSK vs DSSS spreading
%   Fig 4 - Channel view: TX, jammer, received signal
%   Fig 5 - Audio recovery comparison
%   Fig 6 - BER vs SNR: BPSK vs fixed-PG DSSS
%   Fig 7 - Bit-level reconstruction proof
%   Fig 8 - Welch PSD jammer detection
%   Fig 9 - Fixed PG vs adaptive PG performance
% =========================================================================

clear all; close all; clc;

% =========================================================================
% SECTION 1 - JAMMER TYPE SELECTION
% Change this line to switch jammer: 'CW' | 'swept' | 'multitone'
% =========================================================================
JAMMER_TYPE = 'cw';


% =========================================================================
% SECTION 2 - LOAD AUDIO FILE
% =========================================================================
fprintf('Loading audio source...\n');

audio_src_file = 'C:\Users\Rizwan Ali\Music\output2.wav';
[src_folder, src_name, ~] = fileparts(audio_src_file);

[raw_audio, Fs] = audioread(audio_src_file);
raw_audio = raw_audio(:,1);
fprintf('  Loaded: %d samples at %d Hz\n\n', length(raw_audio), Fs);


% =========================================================================
% SECTION 3 - SYSTEM PARAMETERS (all formula-derived via dsss_params)
% =========================================================================
fprintf('Computing system parameters...\n');

p = dsss_params(Fs);

n_pcm    = p.n_pcm;       % PCM bit depth
L        = p.L;            % 2^n_pcm quantization levels
N_bch    = p.N_bch;       % BCH codeword length = 2^m - 1
K_bch    = p.K_bch;       % BCH data bits = N - m*t
R_bch    = p.R_bch;       % Code rate
intDepth = p.intDepth;    % Interleaver depth = 4 * burst_len
Rb       = p.Rb;           % Bit rate = Fs * n_pcm
T_bit    = p.T_bit;        % 1/Rb
sps      = p.sps;          % Samples per symbol
Fs_pulse = p.Fs_pulse;    % Rb * sps
fp       = p.fp;           % Processing gain = ceil(10^(JM/10))
Rc       = p.Rc;           % Chip rate = Rb * PG
m_pn     = p.m_pn;        % LFSR register length
pn_period = p.pn_period;  % 2^m_pn - 1
rolloff  = p.rolloff;     % RRC rolloff
rrc_span = p.rrc_span;   % RRC filter span
BW_bpsk  = p.BW_bpsk_kHz;
BW_dsss  = p.BW_dsss_kHz;
EbN0_dB  = p.EbN0_dB;
snr_adj  = p.snr_adj;

pn_poly  = get_primitive_poly(m_pn);    % tap positions for LFSR
pn_init  = ones(1, m_pn);              % all-ones initial LFSR state

fprintf('  Rb  = %.1f kbps\n', Rb/1000);
fprintf('  PG  = %d  =>  JM = %.1f dB\n', fp, 10*log10(fp));
fprintf('  Rc  = %.4f Mcps\n', Rc/1e6);
fprintf('  BCH(%d,%d)  rate=%.3f\n', N_bch, K_bch, R_bch);
fprintf('  BW_DSSS = %.2f kHz\n\n', BW_dsss);


% =========================================================================
% SECTION 4 - AUDIO EXTRACTION
% =========================================================================
audio_seg  = raw_audio(1 : min(p.Ns_audio, length(raw_audio)));
audio_norm = audio_seg / max(abs(audio_seg));
fprintf('Audio: %d samples (%.2f sec)\n\n', length(audio_norm), length(audio_norm)/Fs);


% =========================================================================
% SECTION 5 - PCM QUANTIZATION  (L = 2^n_pcm levels)
% =========================================================================
fprintf('PCM: %d-bit (%d levels)...\n', n_pcm, L);

audio_pcm = uint8(floor((double(audio_norm) + 1) / 2 * (L-1)));
bits_pcm  = reshape(de2bi(audio_pcm, n_pcm, 'left-msb').', 1, []);
fprintf('  %d bits generated\n\n', length(bits_pcm));


% =========================================================================
% SECTION 6 - BCH ENCODING  BCH(N,K): N=2^m-1, K=N-m*t
% =========================================================================
fprintf('BCH(%d,%d) encoding...\n', N_bch, K_bch);

pad_bch = mod(-length(bits_pcm), K_bch);
msg_gf  = gf(reshape([bits_pcm, zeros(1,pad_bch)], K_bch, []).');
code_gf = bchenc(msg_gf, N_bch, K_bch);
bits_bch = reshape(double(code_gf.x).', [], 1);
fprintf('  %d -> %d bits  (rate %.3f)\n\n', length(bits_pcm), length(bits_bch), R_bch);


% =========================================================================
% SECTION 7 - SCRAMBLING
% =========================================================================
sc_obj  = comm.Scrambler(2, [1 0 0 0 1 0 0 1], [1 0 1 1 0 1 0]);
bits_sc = step(sc_obj, bits_bch);
fprintf('Scrambled: %d bits\n\n', length(bits_sc));


% =========================================================================
% SECTION 8 - INTERLEAVING  (depth = 4 x burst_len)
% =========================================================================
fprintf('Interleaving (depth=%d)...\n', intDepth);
n_cols  = ceil(length(bits_sc) / intDepth);
pad_int = intDepth * n_cols - length(bits_sc);
bits_il = matintrlv([bits_sc; zeros(pad_int,1)], intDepth, n_cols);
fprintf('  %d bits\n\n', length(bits_il));


% =========================================================================
% SECTION 9 - BPSK MODULATION  (0->+1, 1->-1)
% =========================================================================
m_polar   = (1 - 2*double(bits_il)).';
m_polar   = m_polar(:).';
N_bits    = length(m_polar);
T_total   = N_bits * T_bit;
t_base    = (0 : N_bits*sps - 1) / Fs_pulse;
bpsk_wave = repelem(m_polar, sps);
fprintf('BPSK: %d bits @ %.1f kbps  (%.3f sec)\n\n', N_bits, Rb/1000, T_total);


% =========================================================================
% SECTION 10 - LFSR PN SEQUENCE + DSSS SPREADING
% =========================================================================
fprintf('LFSR PN + spreading...\n');

pn_len    = N_bits * fp;
pn_seq    = lfsr_pn_sequence(pn_len, pn_poly, pn_init);
pn_seq    = pn_seq(:).';
m_exp     = repelem(m_polar, fp);
m_exp     = m_exp(:).';
dsss      = m_exp .* pn_seq;

pn_wave   = repelem(pn_seq, sps);
dsss_wave = repelem(dsss, sps);
t_chip    = (0 : length(dsss)*sps - 1) / (Rc * sps);
fprintf('  %d chips\n\n', pn_len);


% =========================================================================
% SECTION 11 - JAMMER
% =========================================================================
fprintf('Jammer [%s]...\n', JAMMER_TYPE);

jparams.Aj           = 0.85;
jparams.fj_norm      = 0.05;
jparams.f_start_norm = 0.02;
jparams.f_stop_norm  = 0.20;
jparams.T_sweep      = 0.5;
jparams.f_tones_norm = [0.05 0.12 0.20];

jammer = jammer_generator(length(dsss), JAMMER_TYPE, jparams);
fj_Hz  = jparams.fj_norm * Rc;
fprintf('  Aj=%.2f  fj=%.2f kHz\n\n', jparams.Aj, fj_Hz/1000);


% =========================================================================
% SECTION 12 - AWGN CHANNEL
% =========================================================================
fprintf('Channel: Eb/N0=%d dB  SNR_adj=%.2f dB\n\n', EbN0_dB, snr_adj);

dsss_tx  = dsss + jammer;
rx_chips = awgn_channel(dsss_tx, snr_adj);
rx_chips = rx_chips(:).';


% =========================================================================
% SECTION 13 - WELCH PSD JAMMER DETECTION
% =========================================================================
fprintf('Spectrum sensing...\n');
[jam_found, jam_freqs_kHz, ~] = psd_jammer_detect(rx_chips, Rc, false);
if jam_found
    fprintf('  Detected at %.1f kHz\n\n', jam_freqs_kHz(1));
else
    fprintf('  No jammer spike found\n\n');
end


% =========================================================================
% SECTION 14 - DESPREADING (integrate-and-dump)
% =========================================================================
desp_chips = rx_chips .* pn_seq;
N_bits_rx  = floor(length(desp_chips) / fp);
desp_mat   = reshape(desp_chips(1:N_bits_rx*fp), fp, N_bits_rx);
integrated = sum(desp_mat, 1);
fprintf('Despread: %d bits\n\n', N_bits_rx);


% =========================================================================
% SECTION 15 - BPSK DEMODULATION
% =========================================================================
bits_dec      = sign(integrated);
bits_dec(bits_dec == 0) = 1;
bits_rx_demod = double(bits_dec < 0);
bits_rx_demod = bits_rx_demod(:);


% =========================================================================
% SECTION 16 - DEINTERLEAVING
% =========================================================================
deint_len = intDepth * n_cols;
tmp       = [bits_rx_demod; zeros(max(0, deint_len-length(bits_rx_demod)), 1)];
tmp       = tmp(1:deint_len);
bits_deil = matdeintrlv(tmp, intDepth, n_cols);
bits_deil = bits_deil(1:end-pad_int);


% =========================================================================
% SECTION 17 - DESCRAMBLING
% =========================================================================
dsc_obj  = comm.Descrambler(2, [1 0 0 0 1 0 0 1], [1 0 1 1 0 1 0]);
bits_dsc = step(dsc_obj, bits_deil);


% =========================================================================
% SECTION 18 - BCH DECODING
% =========================================================================
fprintf('BCH(%d,%d) decoding...\n', N_bch, K_bch);
n_words       = floor(length(bits_dsc) / N_bch);
bits_dsc_trim = bits_dsc(1:n_words*N_bch);
[dec_gf, ~]   = bchdec(gf(reshape(bits_dsc_trim, N_bch, []).'), N_bch, K_bch);
bits_dec_out  = reshape(double(dec_gf.x).', 1, []);
bits_rx       = bits_dec_out(1:end-pad_bch);
fprintf('  %d bits decoded\n\n', length(bits_rx));


% =========================================================================
% SECTION 19 - AUDIO RECONSTRUCTION + SAVE
% =========================================================================
fprintf('Reconstructing audio...\n');

cmp_len  = min(length(bits_pcm), length(bits_rx));
BER      = sum(bits_pcm(1:cmp_len) ~= bits_rx(1:cmp_len)) / cmp_len;

n_bytes  = floor(length(bits_rx) / 8);
rx_u8    = bi2de(reshape(bits_rx(1:n_bytes*8), 8, []).', 'left-msb');
audio_rx = double(rx_u8) / 127.5 - 1;

audio_rx_norm = audio_rx / (max(abs(audio_rx)) + eps);
out_wav = fullfile(src_folder, [src_name '_RECOVERED_DSSS.wav']);
audiowrite(out_wav, audio_rx_norm, Fs);

fprintf('  BER = %.6f  (%.3f%%)\n', BER, BER*100);
fprintf('  Saved: %s\n\n', out_wav);


% =========================================================================
% FIGURE 1 - TX Time Domain  0 to 10 ms
% =========================================================================
plot_time_domain(bpsk_wave, pn_wave, dsss_wave, t_base, ...
    Rb, Rc, fp, T_total, N_bits, 0.01, sps);


% =========================================================================
% FIGURE 2 - RRC Pulse Shaped  0 to 10 ms
% =========================================================================
rrc_h     = rcosdesign(rolloff, rrc_span, sps, 'sqrt');
bpsk_rrc  = upfirdn(m_polar, rrc_h, sps);
dsss_rrc  = upfirdn(dsss, rcosdesign(rolloff, rrc_span, sps, 'sqrt'), sps);

n_br = min(round(10e-3 * Fs_pulse),  length(bpsk_rrc));
n_dr = min(round(10e-3 * Rc * sps),  length(dsss_rrc));

figure('Name','Fig 2: RRC Pulse Shaping','NumberTitle','off','Position',[120 120 950 580]);
set(gcf,'Color','w');

subplot(2,1,1);
plot((0:n_br-1)/Fs_pulse*1e3, bpsk_rrc(1:n_br), ...
    'LineWidth',1.5,'Color',[0.2 0.4 0.8]);
xlim([0 1]); grid on;
xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf('BPSK - RRC  alpha=%.2f  Rb=%.1f kbps  BW=%.1f kHz', ...
    rolloff, Rb/1000, BW_bpsk));

subplot(2,1,2);
plot((0:n_dr-1)/(Rc*sps)*1e3, dsss_rrc(1:n_dr), ...
    'LineWidth',1.2,'Color',[0.15 0.55 0.15]);
xlim([0 0.1]); grid on;
xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf('DSSS - RRC  alpha=%.2f  Rc=%.4f Mcps  BW=%.1f kHz', ...
    rolloff, Rc/1e6, BW_dsss));


% =========================================================================
% FIGURE 3 - Spectrum Analysis
% =========================================================================
plot_frequency_domain(bpsk_wave, dsss, Fs_pulse, Rb, Rc, fp, T_total, rolloff);


% =========================================================================
% FIGURE 4 - Channel Signals  0 to 10 ms
% =========================================================================
jammer_wave = repelem(jammer,   sps);
rx_wave     = repelem(rx_chips, sps);

n_bc = min(round(10e-3 * Fs_pulse),  length(bpsk_wave));
n_cc = min(round(10e-3 * Rc * sps),  min(length(jammer_wave), length(rx_wave)));

figure('Name','Fig 4: Channel Signals','NumberTitle','off','Position',[150 80 1000 720]);
set(gcf,'Color','w');

subplot(3,1,1);
plot(t_base(1:n_bc)*1e3, bpsk_wave(1:n_bc), ...
    'LineWidth',1.5,'Color',[0.2 0.4 0.8]);
xlim([0 0.1]); ylim([-1.5 1.5]); grid on;
xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf('Transmitted DSSS  PG=%d  Rc=%.4f Mcps', fp, Rc/1e6));

subplot(3,1,2);
plot(t_chip(1:n_cc)*1e3, jammer_wave(1:n_cc), ...
    'LineWidth',1.3,'Color',[0.55 0 0.75]);
xlim([0 0.1]); grid on;
xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf('%s Jammer  Aj=%.2f  fj=%.2f kHz', JAMMER_TYPE, jparams.Aj, fj_Hz/1000));

subplot(3,1,3);
plot(t_chip(1:n_cc)*1e3, rx_wave(1:n_cc), ...
    'LineWidth',1.0,'Color',[0.7 0.3 0]);
xlim([0 0.1]); grid on;
xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf('Received (DSSS + Jammer + AWGN)  Eb/N0=%d dB', EbN0_dB));


% =========================================================================
% FIGURE 5 - Audio Recovery
% =========================================================================
% Yeh teen lines replace karo (zoom_ms + y range control):
zoom_ms = 200;                                        % X zoom � kitne ms dikhne hain
y_min   = -0.03;                                      % Y zoom � lower limit
y_max   =  0.06;                                      % Y zoom � upper limit

n_orig  = min(round(zoom_ms*1e-3*Fs), length(audio_norm));
n_rec   = min(round(zoom_ms*1e-3*Fs), length(audio_rx));
t_aud   = (0:n_orig-1)/Fs*1000;

figure('Name','Fig 5: Audio Recovery','NumberTitle','off','Position',[200 180 960 430]);
set(gcf,'Color','w');
plot(t_aud, audio_norm(1:n_orig), 'Color',[0.2 0.4 0.8], 'LineWidth',1.5);
hold on;
if n_rec > 0
    plot((0:n_rec-1)/Fs*1000, audio_rx(1:n_rec), ...
        'Color',[0.8 0.15 0.15], 'LineWidth',1.0, 'LineStyle','--');
end
grid on;
xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf('Audio Recovery  |  Jammer:%s  BER=%.3f%%  Eb/N0=%d dB  PG=%d', ...
    JAMMER_TYPE, BER*100, EbN0_dB, fp));
legend('Original','Recovered','Location','northeast');
xlim([100, zoom_ms]);
ylim([y_min, y_max]);

% =========================================================================
% FIGURE 6 - BER vs SNR
% =========================================================================
fprintf('BER vs SNR curves...\n');

snr_vec = p.snr_range;
seg     = min(1000, N_bits);
m_s     = m_polar(1:seg);
b_s     = double(m_s < 0);
pn_s    = lfsr_pn_sequence(seg*fp, pn_poly, pn_init);
pn_s    = pn_s(:).';
me_s    = repelem(m_s, fp);  me_s = me_s(:).';
ds_s    = me_s .* pn_s;
jam_s   = jammer_generator(length(ds_s), JAMMER_TYPE, jparams);
jb_s    = mean(reshape(jam_s, fp, []), 1);

BER_bpsk = zeros(size(snr_vec));
BER_dsss = zeros(size(snr_vec));

for k = 1:length(snr_vec)
    rx_d = awgn_channel(ds_s + jam_s, snr_vec(k));
    [rb_d, ~] = despread_demodulate(rx_d, pn_s, fp);
    cl = min(length(b_s), length(rb_d));
    BER_dsss(k) = sum(b_s(1:cl) ~= rb_d(1:cl)) / cl;

    rx_b = awgn_channel(m_s + jb_s, snr_vec(k));
    rb_b = double(rx_b < 0);
    cl2  = min(length(b_s), length(rb_b));
    BER_bpsk(k) = sum(b_s(1:cl2) ~= rb_b(1:cl2)) / cl2;
end

figure('Name','Fig 6: BER vs SNR','NumberTitle','off','Position',[200 200 820 490]);
set(gcf,'Color','w');
semilogy(snr_vec, BER_bpsk+1e-10, 'r-o', 'LineWidth',2, 'MarkerSize',7);
hold on;
semilogy(snr_vec, BER_dsss+1e-10, 'b-s', 'LineWidth',2, 'MarkerSize',7);
grid on;
xlabel('SNR (dB)'); ylabel('BER');
title(sprintf('BER vs SNR  |  Jammer:%s  Aj=%.2f  PG=%d', JAMMER_TYPE, jparams.Aj, fp));
legend('BPSK (no spreading)', sprintf('DSSS  PG=%d', fp), 'Location','northeast');
xlim([snr_vec(1) snr_vec(end)]);


% =========================================================================
% FIGURE 7 - Bit Level Validation
% =========================================================================
idx   = 1:60;
lim_r = min(length(bits_rx), 60);

figure('Color','w','Name','Fig 7: Bit Reconstruction','Position',[150 150 1000 500]);

subplot(2,1,1);
stairs([bits_pcm(idx), bits_pcm(idx(end))], 'LineWidth',2,'Color',[0 0.5 0]);
ylim([-0.2 1.2]); grid on;
title('Original Bits (before BCH encoding)');
ylabel('Logic Level'); xlabel('Bit Index'); set(gca,'YTick',[0 1]);

subplot(2,1,2);
stairs([bits_rx(1:lim_r), bits_rx(lim_r)], 'LineWidth',2,'Color',[0.8 0 0]);
ylim([-0.2 1.2]); grid on;
title(sprintf('Recovered Bits  |  Accuracy: %.2f%%  BER=%.5f', (1-BER)*100, BER));
ylabel('Logic Level'); xlabel('Bit Index'); set(gca,'YTick',[0 1]);


% =========================================================================
% FIGURE 8 - Welch PSD Jammer Detection
% =========================================================================
fprintf('Welch PSD figure...\n');
[jam_found, jam_freqs_kHz, ~] = psd_jammer_detect(rx_chips, Rc, true);


% =========================================================================
% FIGURE 9 - Fixed PG vs Adaptive PG
% =========================================================================
fprintf('Adaptive PG controller...\n');

fp_lo      = max(2, floor(fp/4));
fp_hi      = min(128, fp*4);
BER_thr_hi = 0.01;
BER_thr_lo = 0.001;

[fp_conv, BER_adp, PG_tr] = adaptive_pg_controller( ...
    m_s, pn_s, ds_s, jam_s, snr_vec, ...
    fp, fp_lo, fp_hi, BER_thr_hi, BER_thr_lo);

figure('Name','Fig 9: Adaptive PG','NumberTitle','off','Position',[220 150 900 580]);
set(gcf,'Color','w');

subplot(2,1,1);
semilogy(snr_vec, BER_dsss+1e-10, 'b-s', 'LineWidth',2, 'MarkerSize',7);
hold on;
semilogy(snr_vec, BER_adp+1e-10,  'm-^', 'LineWidth',2, 'MarkerSize',7);
grid on;
xlabel('SNR (dB)'); ylabel('BER');
title(sprintf('Fixed PG=%d vs Adaptive PG (range %d to %d)', fp, fp_lo, fp_hi));
legend(sprintf('Fixed PG=%d', fp), ...
    sprintf('Adaptive (converged=%d)', fp_conv), 'Location','northeast');
xlim([snr_vec(1) snr_vec(end)]);

subplot(2,1,2);
bar(snr_vec, PG_tr, 'FaceColor',[0.4 0.2 0.7], 'EdgeColor','none');
hold on;
line([snr_vec(1)-1, snr_vec(end)+1], [fp, fp], ...
    'Color','r', 'LineStyle','--', 'LineWidth',1.5);
text(snr_vec(1), fp + fp*0.1, sprintf('Fixed PG=%d', fp), ...
    'Color','r', 'FontWeight','bold', 'FontSize',9);
grid on;
xlabel('SNR (dB)'); ylabel('PG Used');
title('PG Trace per SNR Point');
ylim([0, fp_hi*1.15]);


% =========================================================================
% CONSOLE SUMMARY
% =========================================================================
fprintf('\n==========================================\n');
fprintf('           SYSTEM SUMMARY\n');
fprintf('==========================================\n');
fprintf('Bit rate         : %.1f kbps\n', Rb/1000);
fprintf('Processing gain  : %d  (JM=%.1f dB)\n', fp, 10*log10(fp));
fprintf('Chip rate        : %.4f Mcps\n', Rc/1e6);
fprintf('BCH(%d,%d)       : rate=%.3f\n', N_bch, K_bch, R_bch);
fprintf('DSSS bandwidth   : %.2f kHz\n', BW_dsss);
fprintf('PN LFSR          : m=%d  period=%d\n', m_pn, pn_period);
fprintf('Interleaver      : depth=%d\n', intDepth);
fprintf('Jammer           : %s  Aj=%.2f  fj=%.2f kHz\n', ...
    JAMMER_TYPE, jparams.Aj, fj_Hz/1000);
fprintf('Eb/N0            : %d dB  (adj=%.2f dB)\n', EbN0_dB, snr_adj);
fprintf('BER              : %.6f (%.3f%%)\n', BER, BER*100);
if jam_found
    fprintf('Jammer detected  : YES at %.1f kHz\n', jam_freqs_kHz(1));
else
    fprintf('Jammer detected  : NO\n');
end
fprintf('Adaptive PG      : converged to %d\n', fp_conv);
fprintf('Recovered audio  : %s\n', out_wav);
fprintf('==========================================\n\n');

n_check = min(100, cmp_len);
bp_check = double(bits_pcm(1:n_check)); bp_check = bp_check(:);
br_check = double(bits_rx(1:n_check));  br_check = br_check(:);
n_err = sum(bp_check ~= br_check);
if n_err == 0
    fprintf('First %d bits: PERFECT MATCH\n\n', n_check);
else
    fprintf('First %d bits: %d errors (%.1f%%)\n\n', n_check, n_err, n_err/n_check*100);
end
