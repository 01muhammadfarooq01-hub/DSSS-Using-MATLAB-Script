%% ========================================================================
%% DSSS BASED ANTI-JAMMING SYSTEM - JAMMER ANALYSIS
%% Exp1_DSSS_jamm_3.m
%% ========================================================================
% This script demonstrates:
%  1. DSSS spreading with jammer interference
%  2. Comparison: BPSK vs DSSS under narrowband jamming
%  3. BER vs SNR curves (with and without jammer)
%  4. Jammer suppression via processing gain
%  5. Bit-level 0/1 waveform validation
%
% FIXES APPLIED:
%   [FIX 1] Vector Orientation Bug:
%     All vectors forced to row vectors using (:).'
%     Prevents 29 Trillion element matrix crash (221,000 GB RAM error).
%   [FIX 2] Pulse Shaping:
%     Root Raised Cosine filter added for realistic bandwidth.
%% ========================================================================

clear all; close all; clc;

%% ========================================================================
%% STEP 1: AUDIO READ & VOICE EXTRACTION
%% ========================================================================
fprintf('=== STEP 1: Loading Voice Data ===\n');

[audio_data, Fs_audio] = audioread('C:\Users\Rizwan Ali\Music\output2.wav');
audio_mono = audio_data(:, 1);

segment = audio_mono(20000:70000);
fprintf('Audio Samples Extracted: %d\n', length(segment));

%% ========================================================================
%% STEP 2: BITS GENERATION FROM VOICE
%% ========================================================================
fprintf('=== STEP 2: Converting Voice to Binary Data ===\n');

audio_8bit    = uint8((segment + 1) * 127.5);
binary_matrix = de2bi(audio_8bit, 8);
bits          = reshape(binary_matrix', 1, []);

m_polar = double((2 * bits) - 1);
m_polar = m_polar(:).';   % [FIX 1] Force row vector

fprintf('Generated Binary Bits: %d\n\n', length(bits));

%% ========================================================================
%% STEP 3: DSSS SPREADING
%% ========================================================================
fprintf('=== STEP 3: DSSS Spreading ===\n');

bit_rate   = 176400;
T_bit      = 1 / bit_rate;
total_bits = length(m_polar);
total_time = total_bits * T_bit;

sps      = 100;
Fs_pulse = bit_rate * sps;

fp        = 10;
pn_length = length(m_polar) * fp;
pn_code   = randi([0,1], 1, pn_length);

pn_code             = double(pn_code);
pn_code(pn_code==0) = -1;
pn_code             = pn_code(:).';   % [FIX 1] Force row vector

message_expanded = repelem(m_polar, fp);
message_expanded = message_expanded(:).';   % [FIX 1] Force row vector

DSSS = message_expanded .* pn_code;         % [FIX 1] Safe element-wise multiply

chip_rate = bit_rate * fp;
T_chip    = 1 / chip_rate;

bpsk_waveform = repelem(m_polar, sps);
pn_waveform   = repelem(pn_code, sps);
dsss_waveform = repelem(DSSS, sps);
t_waveform    = (0:total_bits*sps-1) / Fs_pulse;

fprintf('Processing Gain (fp)      : %d\n', fp);
fprintf('Chip Rate (Rc)            : %.2f Mcps\n', chip_rate/1e6);
fprintf('Jamming Margin            : %.1f dB\n\n', 10*log10(fp));

%% ========================================================================
%% STEP 4: NARROWBAND JAMMER GENERATION
%% ========================================================================
fprintf('=== STEP 4: Jammer Generation ===\n');

% Jammer parameters
Aj = 0.85;                     % Jammer amplitude
fj = chip_rate * 0.05;         % Jammer center frequency (5% of chip rate)

% Time vector for chips
n_chips = (0:length(DSSS)-1);

% Narrowband CW Jammer (worst case for unspread BPSK)
jammer_chips = Aj * sin(2 * pi * (fj / chip_rate) * n_chips);
jammer_chips = jammer_chips(:).';   % [FIX 1] Force row vector

fprintf('Jammer Type               : Narrowband CW\n');
fprintf('Jammer Amplitude          : %.2f\n', Aj);
fprintf('Jammer Frequency          : %.2f kHz\n', fj/1000);
fprintf('Jammer-to-Signal Ratio    : %.1f dB\n\n', 20*log10(Aj));

%% ========================================================================
%% STEP 5: AWGN CHANNEL + JAMMER
%% ========================================================================
fprintf('=== STEP 5: AWGN + Jammer Channel ===\n');

SNR_dB = 10;

% DSSS path (with jammer)
DSSS_jammed  = DSSS + jammer_chips;
received_DSSS = awgn_channel(DSSS_jammed, SNR_dB);

% BPSK path (with same jammer - for comparison)
% Spread jammer over bits for BPSK (downsample jammer to bit rate)
jammer_per_bit = reshape(jammer_chips, fp, []);
jammer_bits    = mean(jammer_per_bit, 1);         % Average per bit
bpsk_jammed    = m_polar + jammer_bits;
received_BPSK  = awgn_channel(bpsk_jammed, SNR_dB);

fprintf('\n');

%% ========================================================================
%% STEP 6: DESPREADING & DEMODULATION
%% ========================================================================
fprintf('=== STEP 6: Despreading & Demodulation ===\n');

[recovered_bits_dsss, recovered_audio_dsss] = despread_demodulate(received_DSSS, pn_code, fp);

% BPSK demodulation (direct threshold decision)
bpsk_decided_rx = double(received_BPSK > 0);

compare_dsss = min(length(bits), length(recovered_bits_dsss));
compare_bpsk = min(length(bits), length(bpsk_decided_rx));

BER_dsss = sum(bits(1:compare_dsss) ~= recovered_bits_dsss(1:compare_dsss)) / compare_dsss;
BER_bpsk = sum(bits(1:compare_bpsk) ~= bpsk_decided_rx(1:compare_bpsk)) / compare_bpsk;

fprintf('\nBER (DSSS with Jammer)    : %.6f (%.4f%%)\n', BER_dsss, BER_dsss*100);
fprintf('BER (BPSK with Jammer)    : %.6f (%.4f%%)\n\n', BER_bpsk, BER_bpsk*100);

%% ========================================================================
%% FIGURE 1: TIME DOMAIN TX SIGNALS  (Square Wave)
%% ========================================================================
fprintf('=== Creating Figure 1: TX Time Domain ===\n');

time_to_plot = 0.1;

plot_time_domain(bpsk_waveform, pn_waveform, dsss_waveform, t_waveform, ...
                 bit_rate, chip_rate, fp, total_time, total_bits, ...
                 time_to_plot, sps);

fprintf('Figure 1: TX time domain created\n');

%% ========================================================================
%% FIGURE 2: RRC PULSE SHAPED SIGNALS  [FIX 2]
%% ========================================================================
fprintf('=== Creating Figure 2: RRC Pulse Shaped Signals ===\n');

rolloff  = 0.35;
rrc_span = 10;
rrc_filt = rcosdesign(rolloff, rrc_span, sps, 'sqrt');

bpsk_rrc = upfirdn(m_polar, rrc_filt, sps);
dsss_rrc = upfirdn(DSSS,    rcosdesign(rolloff, rrc_span, sps, 'sqrt'), sps);

bits_rrc_plot  = min(ceil(time_to_plot * bit_rate * sps), length(bpsk_rrc));
chips_rrc_plot = min(ceil(time_to_plot * chip_rate * sps), length(dsss_rrc));
t_rrc_b = (0:bits_rrc_plot-1) / Fs_pulse * 1e3;
t_rrc_d = (0:chips_rrc_plot-1) / (chip_rate * sps) * 1e3;

figure('Name','RRC Pulse Shaped Signals [Fix 2]','NumberTitle','off','Position',[120 120 900 500]);
set(gcf,'Color','w');
subplot(2,1,1);
plot(t_rrc_b, bpsk_rrc(1:bits_rrc_plot), 'LineWidth', 1.5, 'Color', [0.2 0.4 0.8]);
grid on; xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf('BPSK RRC Shaped | Rolloff=%.2f | Bit Rate=%.1f kbps', rolloff, bit_rate/1000));

subplot(2,1,2);
plot(t_rrc_d, dsss_rrc(1:chips_rrc_plot), 'LineWidth', 1.2, 'Color', [0.2 0.6 0.2]);
grid on; xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf('DSSS RRC Shaped | Rolloff=%.2f | Chip Rate=%.2f Mcps', rolloff, chip_rate/1e6));

fprintf('Figure 2: RRC pulse shaped signals created\n');

%% ========================================================================
%% FIGURE 3: SPECTRUM ANALYSIS
%% ========================================================================
fprintf('=== Creating Figure 3: Spectrum Analysis ===\n');

plot_frequency_domain(bpsk_waveform, DSSS, Fs_pulse, ...
                      bit_rate, chip_rate, fp, total_time);

fprintf('Figure 3: Spectrum analysis created\n');

%% ========================================================================
%% FIGURE 4: JAMMER IMPACT - BPSK vs DSSS COMPARISON
%% ========================================================================
fprintf('=== Creating Figure 4: Jammer Impact Comparison ===\n');

jammer_wave  = repelem(jammer_chips, sps);
rx_dsss_wave = repelem(received_DSSS, sps);
t_chip_wave  = (0:length(received_DSSS)*sps-1) / (chip_rate * sps);

chips_plot = min(ceil(time_to_plot * chip_rate), length(received_DSSS));
smp_plot   = chips_plot * sps;
bits_plot  = min(ceil(time_to_plot * bit_rate * sps), length(bpsk_waveform));

figure('Name','Jammer Impact: BPSK vs DSSS','NumberTitle','off','Position',[150 100 1000 800]);
set(gcf,'Color','w');

subplot(4,1,1);
plot(t_waveform(1:bits_plot)*1e3, bpsk_waveform(1:bits_plot), 'LineWidth',1.5,'Color',[0.2 0.4 0.8]);
grid on; ylim([-1.5 1.5]);
xlabel('Time (ms)'); ylabel('Amplitude');
title('Original BPSK Signal (Clean)');

subplot(4,1,2);
plot(t_chip_wave(1:smp_plot)*1e3, jammer_wave(1:smp_plot), 'LineWidth',1.2,'Color',[0.6 0 0.8]);
grid on;
xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf('Narrowband Jammer | Amplitude=%.2f | Freq=%.1f kHz', Aj, fj/1000));

subplot(4,1,3);
plot(t_chip_wave(1:smp_plot)*1e3, rx_dsss_wave(1:smp_plot), 'LineWidth',1.0,'Color',[0.7 0.3 0.0]);
grid on;
xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf('Received DSSS (With Jammer+AWGN) | BER=%.4f%% | PG=%d', BER_dsss*100, fp));

subplot(4,1,4);
orig_len  = min(4000, length(segment));
recov_len = min(4000, length(recovered_audio_dsss));
t_aud     = (0:orig_len-1)/Fs_audio*1000;
plot(t_aud, segment(1:orig_len), 'Color',[0.2 0.4 0.8], 'LineWidth',1.2);
hold on;
if recov_len > 0
    plot((0:recov_len-1)/Fs_audio*1000, recovered_audio_dsss(1:recov_len), ...
        'Color',[0.8 0.2 0.2],'LineWidth',1.0,'LineStyle','--');
end
grid on;
xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf('Audio Recovery Under Jamming | DSSS BER=%.4f%% vs BPSK BER=%.4f%%', ...
    BER_dsss*100, BER_bpsk*100));
legend('Original','Recovered (DSSS)','Location','northeast');

fprintf('Figure 4: Jammer impact comparison created\n');

%% ========================================================================
%% FIGURE 5: BER vs SNR CURVES (DSSS vs BPSK under Jamming)
%% ========================================================================
fprintf('=== Creating Figure 5: BER vs SNR Curves ===\n');

snr_range   = -5:2:20;
BER_dsss_vs = zeros(size(snr_range));
BER_bpsk_vs = zeros(size(snr_range));

% Use shorter segment for speed
seg_short = min(5000, length(m_polar));
m_short   = m_polar(1:seg_short);
bits_short = bits(1:seg_short);

pn_short  = pn_code(1:seg_short*fp);
me_short  = repelem(m_short, fp);
me_short  = me_short(:).';
dsss_short = me_short .* pn_short;

jammer_s = Aj * sin(2*pi*(fj/chip_rate)*(0:length(dsss_short)-1));
jammer_s = jammer_s(:).';

jammer_b_short = reshape(jammer_s, fp, []);
jammer_b_short = mean(jammer_b_short, 1);

for k = 1:length(snr_range)
    snr_k = snr_range(k);

    % DSSS path
    d_rx = awgn_channel(dsss_short + jammer_s, snr_k);
    [rb_dsss, ~] = despread_demodulate(d_rx, pn_short, fp);
    clen = min(length(bits_short), length(rb_dsss));
    BER_dsss_vs(k) = sum(bits_short(1:clen) ~= rb_dsss(1:clen)) / clen;

    % BPSK path
    b_rx = awgn_channel(m_short + jammer_b_short, snr_k);
    rb_bpsk = double(b_rx > 0);
    clen2 = min(length(bits_short), length(rb_bpsk));
    BER_bpsk_vs(k) = sum(bits_short(1:clen2) ~= rb_bpsk(1:clen2)) / clen2;
end

figure('Name','BER vs SNR: DSSS vs BPSK under Jamming','NumberTitle','off','Position',[200 200 800 500]);
set(gcf,'Color','w');

semilogy(snr_range, BER_bpsk_vs + 1e-10, 'r-o', 'LineWidth', 2, 'MarkerSize', 7);
hold on;
semilogy(snr_range, BER_dsss_vs + 1e-10, 'b-s', 'LineWidth', 2, 'MarkerSize', 7);
grid on;
xlabel('SNR (dB)'); ylabel('BER (log scale)');
title(sprintf('BER vs SNR | BPSK vs DSSS | Jammer Amplitude=%.2f | PG=%d', Aj, fp));
legend(sprintf('BPSK (No Spreading, BER=%.4f)', BER_bpsk), ...
       sprintf('DSSS (PG=%d, BER=%.4f)', fp, BER_dsss), ...
       'Location', 'northeast');
xlim([snr_range(1), snr_range(end)]);

fprintf('Figure 5: BER vs SNR curves created\n');

%% ========================================================================
%% FIGURE 6: BIT-LEVEL VALIDATION (0/1 WAVEFORM)
%% ========================================================================
fprintf('=== Creating Figure 6: Bit-Level Validation ===\n');

plot_range = 1:60;

figure('Color','w','Name','Bit-Level Reconstruction (0/1 Form)','Position',[150 150 1000 500]);

subplot(2,1,1);
stairs([bits(plot_range), bits(plot_range(end))], 'LineWidth', 2, 'Color', [0 0.5 0]);
ylim([-0.2 1.2]); grid on;
title('1. Original Transmitted Bits (0/1 Waveform)');
ylabel('Logic Level'); xlabel('Bit Index');
set(gca, 'YTick', [0 1]);

subplot(2,1,2);
rec_plot = recovered_bits_dsss(plot_range);
stairs([rec_plot, rec_plot(end)], 'LineWidth', 2, 'Color', [0.8 0 0]);
ylim([-0.2 1.2]); grid on;
title(['2. Reconstructed Bits (DSSS, 0/1 Waveform) | Match Accuracy: ', ...
    num2str((1-BER_dsss)*100, '%.2f'), '%']);
ylabel('Logic Level'); xlabel('Bit Index');
set(gca, 'YTick', [0 1]);

fprintf('Figure 6: Bit-level validation created\n\n');

%% ========================================================================
%% CONSOLE VALIDATION REPORT
%% ========================================================================
fprintf('\n--- [BIT VALIDATION REPORT] ---\n');
fprintf('Sample Original Bits:    %s\n', num2str(bits(1:20)));
fprintf('Sample Recovered Bits:   %s\n', num2str(recovered_bits_dsss(1:20)));
if isequal(bits(1:min(100,compare_dsss)), recovered_bits_dsss(1:min(100,compare_dsss)))
    fprintf('Status: First %d bits are a PERFECT match.\n', min(100,compare_dsss));
else
    fprintf('Status: Some bit mismatches detected due to Jammer/Noise.\n');
end

%% ========================================================================
%% FINAL SUMMARY
%% ========================================================================
fprintf('\n========================================\n');
fprintf('   JAMMER ANALYSIS SUMMARY\n');
fprintf('========================================\n\n');

fprintf('--- Signal Parameters ---\n');
fprintf('Bit Rate (Rb)             : %.3f kbps\n', bit_rate/1000);
fprintf('Processing Gain (PG)      : %d\n', fp);
fprintf('Chip Rate (Rc)            : %.3f Mcps\n', chip_rate/1e6);
fprintf('Jamming Margin            : %.1f dB\n\n', 10*log10(fp));

fprintf('--- Jammer ---\n');
fprintf('Type                      : Narrowband CW\n');
fprintf('Amplitude                 : %.2f\n', Aj);
fprintf('Frequency                 : %.1f kHz\n', fj/1000);
fprintf('JSR                       : %.1f dB\n\n', 20*log10(Aj));

fprintf('--- BER Results ---\n');
fprintf('BER (BPSK with Jammer)    : %.6f (%.4f%%)\n', BER_bpsk, BER_bpsk*100);
fprintf('BER (DSSS with Jammer)    : %.6f (%.4f%%)\n', BER_dsss, BER_dsss*100);

if BER_dsss < BER_bpsk
    improvement = BER_bpsk / max(BER_dsss, 1e-10);
    fprintf('DSSS Advantage            : %.1fx better BER\n', improvement);
end

fprintf('\n--- Fixes Applied ---\n');
fprintf('[FIX 1] Vector Orientation : (:).'''' applied to pn_code, message_expanded\n');
fprintf('[FIX 2] Pulse Shaping      : RRC (rolloff=%.2f) in Figure 2\n', rolloff);

fprintf('\n========================================\n');
fprintf('Simulation Complete!\n');
fprintf('Figures Generated:\n');
fprintf('  Figure 1 : TX Time Domain (BPSK, PN, DSSS)\n');
fprintf('  Figure 2 : RRC Pulse Shaped Signals [Fix 2]\n');
fprintf('  Figure 3 : Spectrum Analysis\n');
fprintf('  Figure 4 : Jammer Impact Comparison\n');
fprintf('  Figure 5 : BER vs SNR Curves (BPSK vs DSSS)\n');
fprintf('  Figure 6 : Bit-Level Validation (0/1 Waveforms)\n');
fprintf('========================================\n\n');
