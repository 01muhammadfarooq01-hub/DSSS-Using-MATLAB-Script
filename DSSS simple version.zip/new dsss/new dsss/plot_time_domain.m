function plot_time_domain(bpsk_waveform, pn_waveform, dsss_waveform, t_waveform, ...
                          bit_rate, chip_rate, fp, total_time, total_bits, ...
                          time_to_plot, sps)
%% ========================================================================
%% FUNCTION: plot_time_domain
%% ========================================================================
% PURPOSE  : BPSK, PN sequence, aur DSSS signal ko time domain mein plot karta hai
%
% INPUTS:
%   bpsk_waveform  - BPSK signal waveform (rectangular pulse expanded)
%   pn_waveform    - PN code waveform (chip-level, sps se expand kiya hua)
%   dsss_waveform  - DSSS spread signal waveform
%   t_waveform     - Time vector (seconds mein, BPSK ke liye)
%   bit_rate       - Data bit rate (bps)
%   chip_rate      - PN chip rate (bps)
%   fp             - Processing gain (spreading factor)
%   total_time     - Total signal duration (seconds)
%   total_bits     - Total number of bits
%   time_to_plot   - Kitna time plot karna hai (seconds mein)
%   sps            - Samples per symbol
%
% FIX APPLIED:
%   Vector orientation fix applied to all waveforms.
%% ========================================================================

    % === VECTOR ORIENTATION FIX ===
    bpsk_waveform = bpsk_waveform(:).';
    pn_waveform   = pn_waveform(:).';
    dsss_waveform = dsss_waveform(:).';
    t_waveform    = t_waveform(:).';

    % Kitne samples plot karne hain calculate karo
    bits_to_plot    = min(ceil(time_to_plot * bit_rate), total_bits);
    chips_to_plot   = bits_to_plot * fp;
    samples_to_plot = chips_to_plot * sps;

    % Clamp to actual lengths
    bits_to_plot    = min(bits_to_plot * sps, length(bpsk_waveform));
    samples_to_plot = min(samples_to_plot, length(pn_waveform));
    samples_to_plot = min(samples_to_plot, length(dsss_waveform));
    t_len_bits      = min(bits_to_plot, length(t_waveform));
    t_len_chips     = min(samples_to_plot, length(t_waveform));

    figure('Name','BPSK Baseband Signal','NumberTitle','off','Position',[100 100 900 700]);
    set(gcf, 'Color', 'w');

    % --- Subplot 1: BPSK Signal ---
    subplot(3,1,1);
    plot(t_waveform(1:t_len_bits)*1e3, bpsk_waveform(1:t_len_bits), ...
        'LineWidth', 1.5, 'Color', [0.2 0.4 0.8]);
    grid on; ylim([-1.5 1.5]);
    xlabel('Time (ms)'); ylabel('Amplitude');
    title(sprintf('BPSK Baseband Signal (First %.1f ms) | Bit Rate: %.1f kbps', ...
        time_to_plot*10, bit_rate/1000)); % changed 1000 to 10
    text(0.02, 1.3, sprintf('Total Duration: %.3f sec | Total Bits: %d', ...
        total_time, total_bits), 'FontSize', 9, 'FontWeight', 'bold');

    % --- Subplot 2: PN Sequence ---
    subplot(3,1,2);
    plot(t_waveform(1:t_len_chips)*1e3, pn_waveform(1:t_len_chips), ...
        'LineWidth', 1.2, 'Color', [0.8 0.2 0.2]);
    grid on; ylim([-1.5 1.5]);
    xlabel('Time (ms)'); ylabel('Amplitude');
    title(sprintf('PN Sequence (Spreading Code) | Chip Rate: %.2f Mcps | PG: %d', ...
        chip_rate/1e6, fp));

    % --- Subplot 3: DSSS Spread Signal ---
    subplot(3,1,3);
    plot(t_waveform(1:t_len_chips)*1e3, dsss_waveform(1:t_len_chips), ...
        'LineWidth', 1.2, 'Color', [0.2 0.6 0.2]);
    grid on; ylim([-1.5 1.5]);
    xlabel('Time (ms)'); ylabel('Amplitude');
    title('DSSS Spread Signal (BPSK x PN Code)');

end
