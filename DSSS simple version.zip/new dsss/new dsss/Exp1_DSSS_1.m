%% ========================================================================
%% DSSS BASED ANTI-JAMMING SYSTEM
%% Direct Sequence Spread Spectrum for Voice Communication
%% ========================================================================
% This program demonstrates:
% 1. Voice extraction as source data
% 2. BPSK baseband modulation (binary to bipolar)
% 3. PN sequence generation and DSSS spreading
% 4. Spectrum analysis showing spreading effect
%
% FIXES APPLIED:
%   [FIX 1] Vector Orientation Bug:
%     message_expanded aur pn_code dono ab (:).' se row vectors force kiye
%     gaye hain. Isse pehle agar ek column (Nx1) aur ek row (1xN) hota,
%     MATLAB ek 5.4M x 5.4M = 29 Trillion element ki matrix banane ki
%     koshish karta aur 221,000 GB RAM maangta - ab crash nahi hoga.
%
%   [FIX 2] Pulse Shaping (Root Raised Cosine):
%     repelem se "Ideal Square Waves" banti thi jo theoretically infinite
%     bandwidth leti hain. Ab RRC filter apply kiya gaya hai jo real
%     communication systems mein use hota hai. Square waves sirf
%     visualization ke liye rakhi gayi hain.
%% ========================================================================

clear all; close all; clc;

%% ========================================================================
%% STEP 1: AUDIO READ & VOICE EXTRACTION
%% ========================================================================
fprintf('=== STEP 1: Loading Voice Data ===\n');

[audio_data, Fs_audio] = audioread('C:\Users\Rizwan Ali\Music\output2.wav');
audio_mono = audio_data(:, 1);

segment = audio_mono(20000:70000);

fprintf('Audio Samples Extracted: %d\n', length(segment));
fprintf('Audio Duration: %.3f seconds\n', length(segment)/Fs_audio);
fprintf('Audio Sampling Rate: %.1f kHz\n\n', Fs_audio/1000);

%% ========================================================================
%% STEP 2: BITS GENERATION FROM VOICE
%% ========================================================================
fprintf('=== STEP 2: Converting Voice to Binary Data ===\n');

audio_8bit    = uint8((segment + 1) * 127.5);
binary_matrix = de2bi(audio_8bit, 8);
bits          = reshape(binary_matrix', 1, []);

m_polar = double((2 * bits) - 1);
m_polar = m_polar(:).';   % [FIX 1] Force row vector

fprintf('Generated Binary Bits: %d\n', length(bits));
fprintf('Data converted to bipolar format (-1/+1)\n\n');

%% ========================================================================
%% STEP 3: TIMING & DATA RATE CALCULATION
%% ========================================================================
fprintf('=== STEP 3: Data Rate and Timing Setup ===\n');

bit_rate   = 176400;
T_bit      = 1/bit_rate;
total_bits = length(m_polar);
total_time = total_bits * T_bit;

sps      = 100;
Fs_pulse = bit_rate * sps;

t_waveform    = (0:total_bits*sps-1) / Fs_pulse;
bpsk_waveform = repelem(m_polar, sps);   % Square wave (for visualization)

fprintf('Bit Rate (Rb): %.1f kbps\n', bit_rate/1000);
fprintf('Bit Duration (Tb): %.6f ms\n', T_bit*1000);
fprintf('Total Bits: %d\n', total_bits);
fprintf('Total Signal Duration: %.3f seconds\n', total_time);
fprintf('Samples per bit: %d\n', sps);
fprintf('Waveform Sampling Rate: %.2f MHz\n\n', Fs_pulse/1e6);

%% ========================================================================
%% STEP 4: BPSK BASEBAND MODULATION DISPLAY
%% ========================================================================
fprintf('=== STEP 4: BPSK Baseband Modulation ===\n');
fprintf('Message Signal: Binary 0/1 data\n');
fprintf('BPSK Signal: Bipolar -1/+1 waveform\n');
fprintf('BPSK Symbol Rate: %.2f kbps\n\n', bit_rate/1000);

%% ========================================================================
%% STEP 5: PN SEQUENCE GENERATION & DSSS SPREADING
%% ========================================================================
fprintf('=== STEP 5: PN Sequence Generation & DSSS Spreading ===\n');

fp        = 10;
pn_length = length(m_polar) * fp;
pn_code   = randi([0,1], 1, pn_length);

pn_code             = double(pn_code);
pn_code(pn_code==0) = -1;
pn_code             = pn_code(:).';   % [FIX 1] Force row vector

% [FIX 1] Both vectors are row vectors now - NO crash possible
message_expanded = repelem(m_polar, fp);   % Row vector (fp chips per bit)
message_expanded = message_expanded(:).';  % Double-ensure row vector

DSSS = message_expanded .* pn_code;       % Safe element-wise multiply

pn_waveform   = repelem(pn_code, sps);
dsss_waveform = repelem(DSSS, sps);

chip_rate = bit_rate * fp;
T_chip    = 1/chip_rate;

fprintf('Processing Gain (fp): %d\n', fp);
fprintf('PN Sequence Length: %d chips\n', pn_length);
fprintf('Chip Rate (Rc): %.2f Mcps\n', chip_rate/1e6);
fprintf('Chip Duration (Tc): %.6f microseconds\n', T_chip*1e6);
fprintf('DSSS Signal Created: Message x PN Sequence\n\n');

%% ========================================================================
%% STEP 5b: ROOT RAISED COSINE PULSE SHAPING   [FIX 2]
%% ========================================================================
fprintf('=== STEP 5b: Root Raised Cosine Pulse Shaping (Fix 2) ===\n');
fprintf('NOTE: repelem gives ideal square waves (infinite BW).\n');
fprintf('RRC filter applied for bandwidth-limited realistic signal.\n\n');

rolloff   = 0.35;   % Roll-off factor (0=ideal sinc, 1=widest)
rrc_span  = 10;     % Filter span in symbols
rrc_sps   = sps;    % Samples per symbol

% BPSK RRC shaped signal
rrc_filter   = rcosdesign(rolloff, rrc_span, rrc_sps, 'sqrt');
bpsk_rrc     = upfirdn(m_polar, rrc_filter, rrc_sps);   % Upsample + filter

% DSSS RRC shaped signal (chip-rate)
chip_sps_rrc = sps;
rrc_chip     = rcosdesign(rolloff, rrc_span, chip_sps_rrc, 'sqrt');
dsss_rrc     = upfirdn(DSSS, rrc_chip, chip_sps_rrc);   % Chip-level shaping

fprintf('RRC Filter Roll-off : %.2f\n', rolloff);
fprintf('RRC Filter Span     : %d symbols\n', rrc_span);
fprintf('RRC shaped BPSK samples : %d\n', length(bpsk_rrc));
fprintf('RRC shaped DSSS samples : %d\n\n', length(dsss_rrc));

%% ========================================================================
%% STEP 6: TIME DOMAIN VISUALIZATION (Square Wave) --> FUNCTION CALL
%% ========================================================================
fprintf('=== STEP 6: Creating Time Domain Plots (Square Wave) ===\n');

time_to_plot = 0.1;

plot_time_domain(bpsk_waveform, pn_waveform, dsss_waveform, t_waveform, ...
                 bit_rate, chip_rate, fp, total_time, total_bits, ...
                 time_to_plot, sps);

fprintf('Figure 1: Time domain plots created (Square Wave)\n');

%% ========================================================================
%% STEP 6b: TIME DOMAIN - RRC PULSE SHAPED SIGNALS
%% ========================================================================
fprintf('=== STEP 6b: Creating RRC Pulse Shaped Time Domain Plots ===\n');

delay_sps  = rrc_span * rrc_sps / 2;   % Filter group delay (samples)
t_rrc_bpsk = (0:length(bpsk_rrc)-1) / Fs_pulse - delay_sps/Fs_pulse;
t_rrc_dsss = (0:length(dsss_rrc)-1) / (chip_rate * chip_sps_rrc) - delay_sps/(chip_rate*chip_sps_rrc);

bits_plot_rrc  = min(ceil(time_to_plot * bit_rate * rrc_sps), length(bpsk_rrc));
chips_plot_rrc = min(ceil(time_to_plot * chip_rate * chip_sps_rrc), length(dsss_rrc));

figure('Name','RRC Pulse Shaped Signals (Fix 2)','NumberTitle','off','Position',[120 120 900 600]);
set(gcf,'Color','w');

subplot(2,1,1);
plot(t_rrc_bpsk(1:bits_plot_rrc)*1e3, bpsk_rrc(1:bits_plot_rrc), ...
    'LineWidth', 1.5, 'Color', [0.2 0.4 0.8]);
grid on;
xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf('BPSK - RRC Shaped (Rolloff=%.2f) | Bit Rate: %.1f kbps', rolloff, bit_rate/1000));
legend('RRC Shaped BPSK');

subplot(2,1,2);
plot(t_rrc_dsss(1:chips_plot_rrc)*1e3, dsss_rrc(1:chips_plot_rrc), ...
    'LineWidth', 1.2, 'Color', [0.2 0.6 0.2]);
grid on;
xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf('DSSS - RRC Shaped (Rolloff=%.2f) | Chip Rate: %.2f Mcps', rolloff, chip_rate/1e6));
legend('RRC Shaped DSSS');

fprintf('Figure 2: RRC Pulse Shaped signals plotted\n');

%% ========================================================================
%% STEP 7: FREQUENCY DOMAIN ANALYSIS --> FUNCTION CALL
%% ========================================================================
fprintf('=== STEP 7: Spectrum Analysis ===\n');

plot_frequency_domain(bpsk_waveform, DSSS, Fs_pulse, ...
                      bit_rate, chip_rate, fp, total_time);

fprintf('Figure 3: Spectrum analysis plots created\n\n');

%% ========================================================================
%% STEP 8: DETAILED PARAMETER DISPLAY
%% ========================================================================
fprintf('========================================\n');
fprintf('     DSSS ANTI-JAMMING SYSTEM SUMMARY\n');
fprintf('========================================\n\n');

bw_bpsk = 2 * (bit_rate  / 1000);
bw_dsss = 2 * (chip_rate / 1000);

fprintf('--- Voice Source ---\n');
fprintf('Audio Samples: %d\n', length(segment));
fprintf('Audio Duration: %.3f seconds\n', length(segment)/Fs_audio);
fprintf('Audio Sampling Rate: %.1f kHz\n\n', Fs_audio/1000);

fprintf('--- Binary Data ---\n');
fprintf('Total Bits Generated: %d bits\n', total_bits);
fprintf('Data Format: Bipolar (-1/+1)\n\n');

fprintf('--- BPSK Baseband Modulation ---\n');
fprintf('Bit Rate (Rb): %.3f kbps (%.6f Mbps)\n', bit_rate/1000, bit_rate/1e6);
fprintf('Bit Duration (Tb): %.6f ms\n', T_bit*1000);
fprintf('Signal Duration: %.3f seconds\n', total_time);
fprintf('BPSK Bandwidth (Null-to-Null): %.1f kHz\n\n', bw_bpsk);

fprintf('--- PN Sequence & DSSS Spreading ---\n');
fprintf('Processing Gain (PG): %d\n', fp);
fprintf('Chip Rate (Rc): %.3f Mcps\n', chip_rate/1e6);
fprintf('Chip Duration (Tc): %.6f microseconds\n', T_chip*1e6);
fprintf('PN Sequence Length: %d chips\n', pn_length);
fprintf('DSSS Bandwidth (Null-to-Null): %.1f kHz\n', bw_dsss);
fprintf('Bandwidth Expansion Factor: %dx\n\n', fp);

fprintf('--- Pulse Shaping ---\n');
fprintf('Filter Type: Root Raised Cosine (RRC)\n');
fprintf('Roll-off Factor: %.2f\n', rolloff);
fprintf('RRC BW (99%%): approx %.1f kHz (BPSK) | %.1f kHz (DSSS)\n', ...
    bit_rate*(1+rolloff)/1000, chip_rate*(1+rolloff)/1000);
fprintf('Note: Square wave = infinite BW; RRC gives finite, controlled BW\n\n');

fprintf('--- Spreading Effect ---\n');
fprintf('Original BPSK Bandwidth: %.1f kHz\n', bw_bpsk);
fprintf('Spread DSSS Bandwidth: %.1f kHz\n', bw_dsss);
fprintf('Spectrum Spread Ratio: %.1fx\n', bw_dsss/bw_bpsk);
fprintf('Power Reduction per Hz: %.1f dB (Processing Gain)\n', 10*log10(fp));

SNR_dB     = 10;
SNR_linear = 10^(SNR_dB/10);

C_bpsk = bw_bpsk * 1000 * log2(1 + SNR_linear);
C_dsss = bw_dsss * 1000 * log2(1 + SNR_linear);

fprintf('\n--- Shannon Capacity Analysis (SNR = %d dB) ---\n', SNR_dB);
fprintf('BPSK Channel Capacity: %.2f Mbps\n', C_bpsk/1e6);
if C_bpsk > bit_rate
    fprintf('  Result: Channel CAN support %.1f kbps\n', bit_rate/1000);
else
    fprintf('  Result: Channel CANNOT support %.1f kbps\n', bit_rate/1000);
end

fprintf('\nDSSS Channel Capacity: %.2f Mbps\n', C_dsss/1e6);
if C_dsss > bit_rate
    fprintf('  Result: Channel CAN support %.1f kbps\n', bit_rate/1000);
else
    fprintf('  Result: Channel CANNOT support %.1f kbps\n', bit_rate/1000);
end

fprintf('\n--- Anti-Jamming Benefits ---\n');
fprintf('1. Jamming Margin: %.1f dB (Processing Gain)\n', 10*log10(fp));
fprintf('2. Spectrum Spreading: %dx bandwidth expansion\n', fp);
fprintf('3. Power Spectral Density: Reduced by %.1f dB\n', 10*log10(fp));
fprintf('4. Interference Rejection: Improved by PG factor\n');

fprintf('\n========================================\n');
fprintf('Simulation Complete!\n');
fprintf('Figures Generated:\n');
fprintf('  Figure 1: Time Domain Square Waves (BPSK, PN, DSSS)\n');
fprintf('  Figure 2: RRC Pulse Shaped Signals\n');
fprintf('  Figure 3: Spectrum Analysis (BPSK vs DSSS)\n');
fprintf('========================================\n\n');
