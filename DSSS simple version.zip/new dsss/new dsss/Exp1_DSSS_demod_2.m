%% ========================================================================
%% DSSS BASED ANTI-JAMMING SYSTEM
%% Direct Sequence Spread Spectrum for Voice Communication
%% MERGED VERSION: Old DSSS + New Research-Grade BCH/Scrambler Code
%% ========================================================================
% FIXES APPLIED:
%   [FIX 1] Vector Orientation Bug:
%     pn_code, message_expanded, DSSS sab (:).' se row vectors force kiye.
%     Pehle ek Nx1 aur 1xN ka .* product MATLAB ko 29 Trillion element
%     ki matrix banane par majboor karta tha => 221,000 GB RAM crash.
%
%   [FIX 2] Pulse Shaping (Root Raised Cosine):
%     repelem se ideal square waves ban rahi thi (infinite bandwidth).
%     RRC filter add kiya gaya for realistic band-limited simulation.
%
%   [MERGE] New Research-Grade Code Embedded:
%     BCH(15,11) channel coding, scrambler, interleaver, jammer added.
%     All new plots (Figure 4 onwards) generate automatically.
%% ========================================================================

clear all; close all; clc;

%% ========================================================================
%% ======== PART A: ORIGINAL DSSS SYSTEM (WITH FIXES) ====================
%% ========================================================================

%% ========================================================================
%% STEP 1: AUDIO READ & VOICE EXTRACTION
%% ========================================================================
fprintf('=== STEP 1: Loading Voice Data ===\n');

[audio_data, Fs_audio] = audioread('C:\Users\Rizwan Ali\Music\output2.wav');
audio_mono = audio_data(:, 1);

segment = audio_mono(20000:70000);

fprintf('Audio Samples Extracted: %d\n', length(segment));
fprintf('Audio Duration: %.3f seconds\n', length(segment)/Fs_audio);
fprintf('Audio Sampling Rate: %.1f kHz\n\n', Fs_audio/1000);

%% ========================================================================
%% STEP 2: BITS GENERATION FROM VOICE
%% ========================================================================
fprintf('=== STEP 2: Converting Voice to Binary Data ===\n');

audio_8bit    = uint8((segment + 1) * 127.5);
binary_matrix = de2bi(audio_8bit, 8);
bits          = reshape(binary_matrix', 1, []);

m_polar = double((2 * bits) - 1);
m_polar = m_polar(:).';   % [FIX 1] Force row vector

fprintf('Generated Binary Bits: %d\n', length(bits));
fprintf('Data converted to bipolar format (-1/+1)\n\n');

%% ========================================================================
%% STEP 3: TIMING & DATA RATE CALCULATION
%% ========================================================================
fprintf('=== STEP 3: Data Rate and Timing Setup ===\n');

bit_rate   = 176400;
T_bit      = 1 / bit_rate;
total_bits = length(m_polar);
total_time = total_bits * T_bit;

sps      = 100;
Fs_pulse = bit_rate * sps;

t_waveform    = (0:total_bits*sps-1) / Fs_pulse;
bpsk_waveform = repelem(m_polar, sps);

fprintf('Bit Rate (Rb)             : %.1f kbps\n', bit_rate/1000);
fprintf('Bit Duration (Tb)         : %.6f ms\n', T_bit*1000);
fprintf('Total Bits                : %d\n', total_bits);
fprintf('Total Signal Duration     : %.3f seconds\n', total_time);
fprintf('Samples per bit           : %d\n', sps);
fprintf('Waveform Sampling Rate    : %.2f MHz\n\n', Fs_pulse/1e6);

%% ========================================================================
%% STEP 4: BPSK BASEBAND MODULATION DISPLAY
%% ========================================================================
fprintf('=== STEP 4: BPSK Baseband Modulation ===\n');
fprintf('Message Signal : Binary 0/1 data\n');
fprintf('BPSK Signal    : Bipolar -1/+1 waveform\n');
fprintf('BPSK Symbol Rate: %.2f kbps\n\n', bit_rate/1000);

%% ========================================================================
%% STEP 5: PN SEQUENCE GENERATION & DSSS SPREADING
%% ========================================================================
fprintf('=== STEP 5: PN Sequence Generation & DSSS Spreading ===\n');

fp        = 10;
pn_length = length(m_polar) * fp;
pn_code   = randi([0,1], 1, pn_length);

pn_code             = double(pn_code);
pn_code(pn_code==0) = -1;
pn_code             = pn_code(:).';   % [FIX 1] Force row vector

% [FIX 1] message_expanded also forced to row vector
message_expanded = repelem(m_polar, fp);
message_expanded = message_expanded(:).';   % [FIX 1] Force row vector

DSSS = message_expanded .* pn_code;         % [FIX 1] Now safe - both row vectors

pn_waveform   = repelem(pn_code, sps);
dsss_waveform = repelem(DSSS, sps);

chip_rate = bit_rate * fp;
T_chip    = 1 / chip_rate;

fprintf('Processing Gain (fp)      : %d\n', fp);
fprintf('PN Sequence Length        : %d chips\n', pn_length);
fprintf('Chip Rate (Rc)            : %.2f Mcps\n', chip_rate/1e6);
fprintf('Chip Duration (Tc)        : %.6f microseconds\n', T_chip*1e6);
fprintf('DSSS Signal Created       : Message x PN Sequence\n\n');

%% ========================================================================
%% STEP 5b: ROOT RAISED COSINE PULSE SHAPING   [FIX 2]
%% ========================================================================
fprintf('=== STEP 5b: Root Raised Cosine Pulse Shaping (Fix 2) ===\n');

rolloff   = 0.35;
rrc_span  = 10;
rrc_sps   = sps;

rrc_filter = rcosdesign(rolloff, rrc_span, rrc_sps, 'sqrt');
bpsk_rrc   = upfirdn(m_polar, rrc_filter, rrc_sps);

chip_sps_rrc = sps;
rrc_chip     = rcosdesign(rolloff, rrc_span, chip_sps_rrc, 'sqrt');
dsss_rrc     = upfirdn(DSSS, rrc_chip, chip_sps_rrc);

fprintf('RRC Filter Roll-off         : %.2f\n', rolloff);
fprintf('RRC shaped BPSK samples     : %d\n', length(bpsk_rrc));
fprintf('RRC shaped DSSS samples     : %d\n\n', length(dsss_rrc));

%% ========================================================================
%% STEP 6: AWGN CHANNEL --> FUNCTION CALL
%% ========================================================================
fprintf('=== STEP 6: Passing Through AWGN Channel ===\n');

SNR_dB = 10;   % <-- SNR badlao yahan se (try 5, 10, 20 dB)

received_DSSS = awgn_channel(DSSS, SNR_dB);

fprintf('\n');

%% ========================================================================
%% STEP 7: DESPREADING & DEMODULATION --> FUNCTION CALL
%% ========================================================================
fprintf('=== STEP 7: Despreading & Demodulation (Receiver Side) ===\n');

[recovered_bits, recovered_audio] = despread_demodulate(received_DSSS, pn_code, fp);

fprintf('\n');

%% ========================================================================
%% STEP 8: BER CALCULATION
%% ========================================================================
fprintf('=== STEP 8: BER Calculation ===\n');

compare_len = min(length(bits), length(recovered_bits));
bit_errors  = sum(bits(1:compare_len) ~= recovered_bits(1:compare_len));
BER         = bit_errors / compare_len;

fprintf('Bits Compared             : %d\n', compare_len);
fprintf('Bit Errors                : %d\n', bit_errors);
fprintf('Bit Error Rate (BER)      : %.6f\n', BER);
fprintf('BER (percent)             : %.4f %%\n\n', BER*100);

%% ========================================================================
%% STEP 9: TX SIDE TIME DOMAIN PLOTS --> FUNCTION CALL  (FIGURE 1)
%% ========================================================================
fprintf('=== STEP 9: Creating Time Domain Plots ===\n');

time_to_plot = 0.1;

plot_time_domain(bpsk_waveform, pn_waveform, dsss_waveform, t_waveform, ...
                 bit_rate, chip_rate, fp, total_time, total_bits, ...
                 time_to_plot, sps);

fprintf('Figure 1: Time domain plots created (TX side - Square Wave)\n');

%% ========================================================================
%% STEP 9b: RRC PULSE SHAPED TIME DOMAIN PLOTS  (FIGURE 2)
%% ========================================================================
fprintf('=== STEP 9b: RRC Pulse Shaped Time Domain Plots ===\n');

delay_sps  = rrc_span * rrc_sps / 2;
t_rrc_bpsk = (0:length(bpsk_rrc)-1) / Fs_pulse - delay_sps/Fs_pulse;
t_rrc_dsss = (0:length(dsss_rrc)-1) / (chip_rate * chip_sps_rrc);

bits_plot_rrc  = min(ceil(time_to_plot * bit_rate * rrc_sps), length(bpsk_rrc));
chips_plot_rrc = min(ceil(time_to_plot * chip_rate * chip_sps_rrc), length(dsss_rrc));

figure('Name','RRC Pulse Shaped Signals [Fix 2]','NumberTitle','off','Position',[120 120 900 600]);
set(gcf,'Color','w');

subplot(2,1,1);
plot(t_rrc_bpsk(1:bits_plot_rrc)*1e3, bpsk_rrc(1:bits_plot_rrc), ...
    'LineWidth', 1.5, 'Color', [0.2 0.4 0.8]);
grid on;
xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf('BPSK - RRC Shaped (Rolloff=%.2f) | Bit Rate: %.1f kbps', rolloff, bit_rate/1000));

subplot(2,1,2);
plot(t_rrc_dsss(1:chips_plot_rrc)*1e3, dsss_rrc(1:chips_plot_rrc), ...
    'LineWidth', 1.2, 'Color', [0.2 0.6 0.2]);
grid on;
xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf('DSSS - RRC Shaped (Rolloff=%.2f) | Chip Rate: %.2f Mcps', rolloff, chip_rate/1e6));

fprintf('Figure 2: RRC Pulse Shaped signals plotted\n');

%% ========================================================================
%% STEP 10: FREQUENCY DOMAIN PLOTS --> FUNCTION CALL  (FIGURE 3)
%% ========================================================================
fprintf('=== STEP 10: Spectrum Analysis ===\n');

plot_frequency_domain(bpsk_waveform, DSSS, Fs_pulse, ...
                      bit_rate, chip_rate, fp, total_time);

fprintf('Figure 3: Spectrum analysis plots created\n\n');

%% ========================================================================
%% STEP 11: RECEIVER SIDE TIME DOMAIN PLOT  (FIGURE 4)
%% ========================================================================
fprintf('=== STEP 11: Receiver Side Time Domain Plots ===\n');

received_waveform = repelem(received_DSSS, sps);
t_chip_waveform   = (0:length(received_DSSS)*sps-1) / (chip_rate * sps);

chips_to_plot   = min(ceil(time_to_plot * chip_rate), length(received_DSSS));
samples_rx_plot = chips_to_plot * sps;

figure('Name','Receiver Side Signals','NumberTitle','off','Position',[200 150 900 700]);
set(gcf, 'Color', 'w');

subplot(3,1,1);
plot(t_chip_waveform(1:samples_rx_plot)*1e3, received_waveform(1:samples_rx_plot), ...
    'LineWidth', 1.2, 'Color', [0.7 0.3 0.0]);
grid on;
xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf('Received Noisy DSSS Signal | SNR = %d dB', SNR_dB));

bits_to_plot_rx = min(ceil(time_to_plot * bit_rate) * sps, length(bpsk_waveform));
subplot(3,1,2);
plot(t_waveform(1:bits_to_plot_rx)*1e3, bpsk_waveform(1:bits_to_plot_rx), ...
    'LineWidth', 1.5, 'Color', [0.2 0.4 0.8]);
grid on; ylim([-1.5 1.5]);
xlabel('Time (ms)'); ylabel('Amplitude');
title('Original BPSK Signal (Transmitted - Reference)');

subplot(3,1,3);
orig_len  = min(5000, length(segment));
recov_len = min(5000, length(recovered_audio));
t_audio   = (0:orig_len-1) / Fs_audio * 1000;

plot(t_audio, segment(1:orig_len), 'Color', [0.2 0.4 0.8], 'LineWidth', 1.2);
hold on;
if recov_len > 0
    plot((0:recov_len-1)/Fs_audio*1000, recovered_audio(1:recov_len), ...
        'Color', [0.8 0.2 0.2], 'LineWidth', 1.0, 'LineStyle', '--');
end
grid on;
xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf('Audio Recovery | Original (Blue) vs Recovered (Red) | BER = %.4f%%', BER*100));
legend('Original Audio', 'Recovered Audio', 'Location', 'northeast');

fprintf('Figure 4: Receiver side plots created\n\n');

%% ========================================================================
%% ======== PART B: RESEARCH-GRADE CODE (BCH + SCRAMBLER + JAMMER) ========
%% ========================================================================
fprintf('\n');
fprintf('========================================\n');
fprintf('   PART B: RESEARCH-GRADE SYSTEM START\n');
fprintf('   BCH Coding + Scrambling + Jammer\n');
fprintf('========================================\n\n');

%% ========================================================================
%% PART B - STEP 1: SOURCE & ENCODING (BCH 15,11)
%% ========================================================================
fprintf('=== PART B - STEP 1: Source & BCH Channel Encoding ===\n');

% Use same audio segment from Part A (already loaded)
audio_b = segment / max(abs(segment));   % Normalize

% PCM quantization (8-bit)
bits_tx = reshape(de2bi(uint8((audio_b+1)*127.5), 8, 'left-msb').', 1, []);

% BCH(15,11) encoding
N_bch = 15; K_bch = 11;
pad_bch = mod(-length(bits_tx), K_bch);
msg_gf  = gf(reshape([bits_tx, zeros(1, pad_bch)], K_bch, []).');
code_gf = bchenc(msg_gf, N_bch, K_bch);
bits_bch = reshape(double(code_gf.x).', [], 1);

fprintf('Original bits             : %d\n', length(bits_tx));
fprintf('BCH(%d,%d) encoded bits   : %d\n', N_bch, K_bch, length(bits_bch));
fprintf('Code Rate                 : %.3f\n', K_bch/N_bch);

%% ========================================================================
%% PART B - STEP 2: SCRAMBLING & INTERLEAVING
%% ========================================================================
fprintf('=== PART B - STEP 2: Scrambling & Interleaving ===\n');

scrambler  = comm.Scrambler(2, [1 0 0 0 1 0 0 1], [1 0 1 1 0 1 0]);
bits_scr   = step(scrambler, bits_bch);

intDepth   = 80;
cols_int   = ceil(length(bits_scr)/intDepth);
pad_int    = intDepth*cols_int - length(bits_scr);
bits_int   = matintrlv([bits_scr; zeros(pad_int, 1)], intDepth, cols_int);

fprintf('After scrambling          : %d bits\n', length(bits_scr));
fprintf('Interleaver depth         : %d\n', intDepth);
fprintf('After interleaving        : %d bits\n', length(bits_int));

%% ========================================================================
%% PART B - STEP 3: CHANNEL (AWGN + NARROWBAND JAMMER)
%% ========================================================================
fprintf('=== PART B - STEP 3: AWGN Channel + Jammer ===\n');

tx_signal_b = 1 - 2*double(bits_int);   % BPSK bipolar

Aj_b = 0.85; fj_b = 0.05;
n_b  = (0:length(tx_signal_b)-1).';
jammer_b = Aj_b * sin(2 * pi * fj_b * n_b);

EbN0_dB_b = 7;
snr_b      = EbN0_dB_b + 10*log10(K_bch/N_bch);
rx_signal_b = awgn(tx_signal_b + jammer_b, snr_b, 'measured');

fprintf('Jammer Amplitude          : %.2f\n', Aj_b);
fprintf('Jammer Frequency          : %.2f (normalized)\n', fj_b);
fprintf('Eb/N0                     : %d dB\n', EbN0_dB_b);

%% ========================================================================
%% PART B - STEP 4: RECEIVER & RECONSTRUCTION
%% ========================================================================
fprintf('=== PART B - STEP 4: Receiver & Reconstruction ===\n');

bits_demod_b  = double(rx_signal_b < 0);
bits_deint_b  = matdeintrlv(bits_demod_b, intDepth, cols_int);
bits_deint_b  = bits_deint_b(1:end-pad_int);

descrambler   = comm.Descrambler(2, [1 0 0 0 1 0 0 1], [1 0 1 1 0 1 0]);
bits_descr_b  = step(descrambler, bits_deint_b);

[dec_gf, ~]   = bchdec(gf(reshape(bits_descr_b, N_bch, []).'), N_bch, K_bch);
bits_rx_stream = reshape(double(dec_gf.x).', 1, []);
bits_rx        = bits_rx_stream(1:end-pad_bch);

min_len_b = min(length(bits_tx), length(bits_rx));
BER_b     = sum(bits_tx(1:min_len_b) ~= bits_rx(1:min_len_b)) / min_len_b;

rx_u8      = bi2de(reshape(bits_rx(1:floor(min_len_b/8)*8), 8, []).', 'left-msb');
audio_rx_b = (double(rx_u8) / 127.5) - 1;

fprintf('BER (Part B)              : %.6f (%.4f%%)\n\n', BER_b, BER_b*100);

%% ========================================================================
%% PART B - FIGURE 5: CHANNEL SIGNAL PLOTS (TX, Jammer, RX)
%% ========================================================================
fprintf('=== PART B: Figure 5 - Channel Signal Analysis ===\n');

plot_samples = min(200, length(tx_signal_b));
t_plot_b     = (0:plot_samples-1);

figure('Name','Part B: Channel Signals (AWGN + Jammer)','NumberTitle','off','Position',[180 100 1000 700]);
set(gcf,'Color','w');

subplot(3,1,1);
stairs(t_plot_b, tx_signal_b(1:plot_samples), 'LineWidth', 1.5, 'Color', [0 0.5 0]);
ylim([-1.5 1.5]); grid on;
xlabel('Sample Index'); ylabel('Amplitude');
title('Transmitted BPSK Signal (Part B - BCH Encoded + Scrambled)');

subplot(3,1,2);
plot(t_plot_b, jammer_b(1:plot_samples), 'LineWidth', 1.5, 'Color', [0.8 0 0.8]);
grid on;
xlabel('Sample Index'); ylabel('Amplitude');
title(sprintf('Narrowband Jammer | Amplitude=%.2f | Freq=%.2f (normalized)', Aj_b, fj_b));

subplot(3,1,3);
plot(t_plot_b, rx_signal_b(1:plot_samples), 'LineWidth', 1.0, 'Color', [0.7 0.3 0.0]);
grid on;
xlabel('Sample Index'); ylabel('Amplitude');
title(sprintf('Received Signal (TX + Jammer + AWGN) | Eb/N0 = %d dB', EbN0_dB_b));

fprintf('Figure 5: Channel signals plotted\n');

%% ========================================================================
%% PART B - FIGURE 6: BIT-LEVEL VALIDATION (0/1 WAVEFORM)
%% ========================================================================
fprintf('=== PART B: Figure 6 - Bit-Level Validation ===\n');

plot_range_b = 1:60;

figure('Color','w','Name','Part B: Bit-Level Reconstruction (0/1 Form)','Position',[150 150 1000 500]);

subplot(2,1,1);
stairs([bits_tx(plot_range_b), bits_tx(plot_range_b(end))], ...
    'LineWidth', 2, 'Color', [0 0.5 0]);
ylim([-0.2 1.2]); grid on;
title('1. Original Transmitted Bits (0/1 Waveform)');
ylabel('Logic Level'); xlabel('Bit Index');
set(gca, 'YTick', [0 1]);

subplot(2,1,2);
stairs([bits_rx(plot_range_b), bits_rx(plot_range_b(end))], ...
    'LineWidth', 2, 'Color', [0.8 0 0]);
ylim([-0.2 1.2]); grid on;
title(['2. Reconstructed Bits (0/1 Waveform) | Match Accuracy: ', ...
    num2str((1-BER_b)*100, '%.2f'), '%']);
ylabel('Logic Level'); xlabel('Bit Index');
set(gca, 'YTick', [0 1]);

fprintf('Figure 6: Bit-level validation plotted\n');

%% ========================================================================
%% PART B - FIGURE 7: AUDIO COMPARISON (Part B)
%% ========================================================================
fprintf('=== PART B: Figure 7 - Audio Recovery Comparison ===\n');

orig_len_b  = min(5000, length(audio_b));
recov_len_b = min(5000, length(audio_rx_b));
t_audio_b   = (0:orig_len_b-1) / Fs_audio * 1000;

figure('Name','Part B: Audio Recovery','NumberTitle','off','Position',[200 200 900 400]);
set(gcf,'Color','w');

plot(t_audio_b, audio_b(1:orig_len_b), 'Color',[0.2 0.4 0.8], 'LineWidth', 1.2);
hold on;
if recov_len_b > 0
    plot((0:recov_len_b-1)/Fs_audio*1000, audio_rx_b(1:recov_len_b), ...
        'Color',[0.8 0.2 0.2], 'LineWidth', 1.0, 'LineStyle', '--');
end
grid on;
xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf('Part B Audio Recovery | BER=%.4f%% | BCH(%d,%d) + Scrambler + Jammer', ...
    BER_b*100, N_bch, K_bch));
legend('Original Audio','Recovered Audio','Location','northeast');

fprintf('Figure 7: Audio recovery comparison plotted\n\n');

%% ========================================================================
%% PART B - CONSOLE VALIDATION REPORT
%% ========================================================================
fprintf('\n--- [BIT VALIDATION REPORT - PART B] ---\n');
fprintf('Sample Original Bits:    %s\n', num2str(bits_tx(1:20)));
fprintf('Sample Recovered Bits:   %s\n', num2str(bits_rx(1:20)));
if isequal(bits_tx(1:min(100,min_len_b)), bits_rx(1:min(100,min_len_b)))
    fprintf('Status: First %d bits are a PERFECT match.\n', min(100,min_len_b));
else
    fprintf('Status: Some bit mismatches detected due to Jammer/Noise.\n');
end

%% ========================================================================
%% FINAL SYSTEM SUMMARY
%% ========================================================================
bw_bpsk = 2 * (bit_rate  / 1000);
bw_dsss = 2 * (chip_rate / 1000);

fprintf('\n========================================\n');
fprintf('   COMPLETE SYSTEM SUMMARY\n');
fprintf('========================================\n\n');

fprintf('--- Part A: Basic DSSS ---\n');
fprintf('Bit Rate (Rb)             : %.3f kbps\n', bit_rate/1000);
fprintf('Processing Gain (PG)      : %d\n', fp);
fprintf('Chip Rate (Rc)            : %.3f Mcps\n', chip_rate/1e6);
fprintf('DSSS Bandwidth            : %.1f kHz\n', bw_dsss);
fprintf('SNR (Part A)              : %d dB\n', SNR_dB);
fprintf('BER (Part A)              : %.6f (%.4f%%)\n\n', BER, BER*100);

fprintf('--- Part B: Research-Grade BCH + Jammer ---\n');
fprintf('BCH Code                  : (%d,%d)\n', N_bch, K_bch);
fprintf('Code Rate                 : %.3f\n', K_bch/N_bch);
fprintf('Scrambler                 : comm.Scrambler [1 0 0 0 1 0 0 1]\n');
fprintf('Interleaver Depth         : %d\n', intDepth);
fprintf('Jammer Amplitude          : %.2f\n', Aj_b);
fprintf('Eb/N0 (Part B)            : %d dB\n', EbN0_dB_b);
fprintf('BER (Part B)              : %.6f (%.4f%%)\n\n', BER_b, BER_b*100);

fprintf('--- Fixes Applied ---\n');
fprintf('[FIX 1] Vector Orientation: message_expanded(:).'', pn_code(:).''\n');
fprintf('[FIX 2] Pulse Shaping     : Root Raised Cosine (rolloff=%.2f)\n', rolloff);

fprintf('\n========================================\n');
fprintf('Simulation Complete!\n');
fprintf('Figures Generated:\n');
fprintf('  Figure 1 : Time Domain TX (BPSK, PN, DSSS) - Square Wave\n');
fprintf('  Figure 2 : RRC Pulse Shaped Signals [Fix 2]\n');
fprintf('  Figure 3 : Spectrum Analysis (BPSK vs DSSS)\n');
fprintf('  Figure 4 : Receiver Side (Noisy RX, Original, Recovered Audio)\n');
fprintf('  Figure 5 : Part B - Channel Signals (TX, Jammer, RX)\n');
fprintf('  Figure 6 : Part B - Bit-Level Validation (0/1 Waveforms)\n');
fprintf('  Figure 7 : Part B - Audio Recovery Comparison\n');
fprintf('========================================\n\n');
