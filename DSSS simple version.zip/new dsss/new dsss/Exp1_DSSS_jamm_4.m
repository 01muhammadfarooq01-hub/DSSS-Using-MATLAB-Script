%% ========================================================================
%% DSSS BASED ANTI-JAMMING SYSTEM
%% ========================================================================
%  COMPLETE CHAIN:
%  Voice Source --> BCH Encoder --> Scrambler --> Interleaver -->
%  Baseband BPSK --> DSSS Spreading --> AWGN Channel + Jammer -->
%  Despreading --> Demodulation --> Deinterleaver --> Descrambler -->
%  BCH Decoder --> Audio Output
%
%  FIGURES:
%    Fig 1: TX Time Domain (BPSK, PN, DSSS)
%    Fig 2: RRC Pulse Shaped Signals          
%    Fig 3: Spectrum Analysis (BPSK vs DSSS)
%    Fig 4: Channel Signals 
%    Fig 5: Audio Recovery Comparison
%    Fig 6: BER vs SNR Curves
%    Fig 7: Bit-Level 0/1 Waveform Validation 
%% ========================================================================

clear all; close all; clc;

%% ========================================================================
%% STEP 1: VOICE SOURCE LOADING
%% ========================================================================
fprintf('=== STEP 1: Voice Source Loading ===\n');

[audio_data, Fs_audio] = audioread('C:\Users\Rizwan Ali\Music\output1.wav');
audio_mono = audio_data(:, 1);

audio_raw  = audio_mono(1:min(44100, length(audio_mono)));
audio_norm = audio_raw / max(abs(audio_raw));   % Normalize to [-1, +1]

fprintf('Audio Samples             : %d\n', length(audio_norm));
fprintf('Audio Duration            : %.3f sec\n', length(audio_norm)/Fs_audio);
fprintf('Audio Sampling Rate       : %.1f kHz\n\n', Fs_audio/1000);

%% ========================================================================
%% STEP 2: PCM QUANTIZATION (8-bit)
%% ========================================================================
fprintf('=== STEP 2: PCM Quantization (8-bit) ===\n');

audio_8bit = uint8((audio_norm + 1) * 127.5);
bits_pcm   = reshape(de2bi(audio_8bit, 8, 'left-msb').', 1, []); 

fprintf('PCM Bits Generated        : %d\n\n', length(bits_pcm));

%% ========================================================================
%% STEP 3: BCH (15,11) CHANNEL ENCODING
%% ========================================================================
fprintf('=== STEP 3: BCH(15,11) Encoding ===\n');

N_bch = 15; K_bch = 11;
pad_bch = mod(-length(bits_pcm), K_bch);

msg_gf  = gf(reshape([bits_pcm, zeros(1, pad_bch)], K_bch, []).');
code_gf = bchenc(msg_gf, N_bch, K_bch);
bits_bch = reshape(double(code_gf.x).', [], 1);   

fprintf('PCM Input Bits            : %d\n', length(bits_pcm));
fprintf('Padding Added             : %d bits\n', pad_bch);
fprintf('BCH Encoded Bits          : %d\n', length(bits_bch));
fprintf('Code Rate                 : %d/%d = %.4f\n\n', K_bch, N_bch, K_bch/N_bch);

%% ========================================================================
%% STEP 4: SCRAMBLING
%% ========================================================================
fprintf('=== STEP 4: Scrambling ===\n');

scrambler = comm.Scrambler(2, [1 0 0 0 1 0 0 1], [1 0 1 1 0 1 0]);
bits_scr  = step(scrambler, bits_bch);  

fprintf('Scrambled Bits            : %d\n\n', length(bits_scr));

%% ========================================================================
%% STEP 5: INTERLEAVING
%% ========================================================================
fprintf('=== STEP 5: Interleaving ===\n');

intDepth = 80;
cols_int = ceil(length(bits_scr) / intDepth);
pad_int  = intDepth * cols_int - length(bits_scr);

bits_int = matintrlv([bits_scr; zeros(pad_int, 1)], intDepth, cols_int);

fprintf('Interleaver Depth         : %d\n', intDepth);
fprintf('Padding (int)             : %d bits\n', pad_int);
fprintf('Interleaved Bits          : %d\n\n', length(bits_int));

%% ========================================================================
%% STEP 6: BASEBAND BPSK MODULATION
%% ========================================================================
fprintf('=== STEP 6: Baseband BPSK Modulation ===\n');

% 0 -> +1, 1 -> -1  (standard BPSK bipolar mapping)
m_polar = (1 - 2*double(bits_int)).';   
m_polar = m_polar(:).';                

bit_rate   = 176400;
T_bit      = 1 / bit_rate;
total_bits = length(m_polar);
total_time = total_bits * T_bit;

sps      = 100;
Fs_pulse = bit_rate * sps;

t_waveform    = (0:total_bits*sps-1) / Fs_pulse;
bpsk_waveform = repelem(m_polar, sps);

fprintf('Bit Rate (Rb)             : %.1f kbps\n', bit_rate/1000);
fprintf('Total BPSK Bits           : %d\n', total_bits);
fprintf('Samples per Symbol        : %d\n\n', sps);

%% ========================================================================
%% STEP 7: DSSS SPREADING (BPSK x PN Code)
%% ========================================================================
fprintf('=== STEP 7: DSSS Spreading ===\n');

fp        = 10;
pn_length = length(m_polar) * fp;
pn_code   = randi([0,1], 1, pn_length);
pn_code   = double(pn_code);
pn_code(pn_code==0) = -1;
pn_code   = pn_code(:).';  

message_expanded = repelem(m_polar, fp);
message_expanded = message_expanded(:).';  
DSSS = message_expanded .* pn_code;   %  DSSS performed here

pn_waveform   = repelem(pn_code, sps);
dsss_waveform = repelem(DSSS, sps);

chip_rate = bit_rate * fp;
T_chip    = 1 / chip_rate;

fprintf('Processing Gain (fp)      : %d\n', fp);
fprintf('Chip Rate (Rc)            : %.2f Mcps\n', chip_rate/1e6);
fprintf('PN Chips                  : %d\n', pn_length);
fprintf('Jamming Margin            : %.1f dB\n\n', 10*log10(fp));

%% ========================================================================
%% STEP 8: AWGN CHANNEL + NARROWBAND JAMMER
%% ========================================================================
fprintf('=== STEP 8: AWGN Channel + Jammer ===\n');

Aj      = 0.85;
fj_norm = 0.05;   % Normalized jammer frequency (0.05 * chip_rate)
n_c     = (0:length(DSSS)-1).';
jammer_c = Aj * sin(2 * pi * fj_norm * n_c);
jammer_c = jammer_c(:).';  

EbN0_dB  = 7;
snr_adj  = EbN0_dB + 10*log10(K_bch/N_bch);

DSSS_jammed   = DSSS + jammer_c;
received_DSSS = awgn_channel(DSSS_jammed, snr_adj);
received_DSSS = received_DSSS(:).';   

fprintf('Jammer Amplitude (Aj)     : %.2f\n', Aj);
fprintf('Jammer Freq               : %.1f kHz\n', fj_norm*chip_rate/1000);
fprintf('Eb/N0                     : %d dB\n', EbN0_dB);
fprintf('SNR (code-rate adjusted)  : %.2f dB\n\n', snr_adj);

%% ========================================================================
%% STEP 9: DESPREADING
%% ========================================================================
fprintf('=== STEP 9: Despreading (Received x PN Code) ===\n');

despread_chips = received_DSSS .* pn_code;

total_bits_rx = floor(length(despread_chips) / fp);
despread_mat  = reshape(despread_chips(1:total_bits_rx*fp), fp, total_bits_rx);
integrated    = sum(despread_mat, 1);   % Sum fp chips per bit

fprintf('Despread & Integrated Bits: %d\n\n', total_bits_rx);

%% ========================================================================
%% STEP 10: BPSK DEMODULATION
%% ========================================================================
fprintf('=== STEP 10: BPSK Demodulation ===\n');

bpsk_decided = sign(integrated);
bpsk_decided(bpsk_decided == 0) = 1;

% +1 -> bit=0, -1 -> bit=1  (inverse of our mapping)
bits_demod_rx = double(bpsk_decided < 0);
bits_demod_rx = bits_demod_rx(:);   

fprintf('Demodulated Bits          : %d\n\n', length(bits_demod_rx));

%% ========================================================================
%% STEP 11: DEINTERLEAVING
%% ========================================================================
fprintf('=== STEP 11: Deinterleaving ===\n');

deint_len      = intDepth * cols_int;
bits_dm_pad    = [bits_demod_rx; zeros(max(0, deint_len-length(bits_demod_rx)), 1)];
bits_dm_pad    = bits_dm_pad(1:deint_len);

bits_deint     = matdeintrlv(bits_dm_pad, intDepth, cols_int);
bits_deint     = bits_deint(1:end-pad_int);

fprintf('Deinterleaved Bits        : %d\n\n', length(bits_deint));

%% ========================================================================
%% STEP 12: DESCRAMBLING
%% ========================================================================
fprintf('=== STEP 12: Descrambling ===\n');

descrambler = comm.Descrambler(2, [1 0 0 0 1 0 0 1], [1 0 1 1 0 1 0]);
bits_descr  = step(descrambler, bits_deint);

fprintf('Descrambled Bits          : %d\n\n', length(bits_descr));

%% ========================================================================
%% STEP 13: BCH (15,11) DECODING
%% ========================================================================
fprintf('=== STEP 13: BCH(15,11) Decoding ===\n');

num_codewords   = floor(length(bits_descr) / N_bch);
bits_descr_trim = bits_descr(1:num_codewords * N_bch);

[dec_gf, ~]     = bchdec(gf(reshape(bits_descr_trim, N_bch, []).'), N_bch, K_bch);
bits_rx_stream  = reshape(double(dec_gf.x).', 1, []);
bits_rx         = bits_rx_stream(1:end-pad_bch);

fprintf('BCH Decoded Bits          : %d\n\n', length(bits_rx));

%% ========================================================================
%% STEP 14: AUDIO OUTPUT RECONSTRUCTION
%% ========================================================================
fprintf('=== STEP 14: Audio Reconstruction ===\n');

min_len  = min(length(bits_pcm), length(bits_rx));
BER      = sum(bits_pcm(1:min_len) ~= bits_rx(1:min_len)) / min_len;

total_bytes_rx = floor(length(bits_rx) / 8);
bits_rx_trim   = bits_rx(1:total_bytes_rx*8);
rx_u8          = bi2de(reshape(bits_rx_trim, 8, []).', 'left-msb');
audio_rx       = (double(rx_u8) / 127.5) - 1;

fprintf('Bits Compared             : %d\n', min_len);
fprintf('Bit Errors                : %d\n', round(BER*min_len));
fprintf('BER                       : %.6f (%.4f%%)\n', BER, BER*100);
fprintf('Recovered Audio Samples   : %d\n\n', length(audio_rx));

%% ========================================================================
%% FIGURE 1: TX TIME DOMAIN (Square Wave) --> FUNCTION CALL
%% ========================================================================
time_to_plot = 0.1;

plot_time_domain(bpsk_waveform, pn_waveform, dsss_waveform, t_waveform, ...
                 bit_rate, chip_rate, fp, total_time, total_bits, ...
                 time_to_plot, sps);

%% ========================================================================
%% FIGURE 2: RRC PULSE SHAPED SIGNALS
%% ========================================================================

rolloff  = 0.35;
rrc_span = 10;
rrc_filt = rcosdesign(rolloff, rrc_span, sps, 'sqrt');

bpsk_rrc = upfirdn(m_polar, rrc_filt, sps);
dsss_rrc = upfirdn(DSSS, rcosdesign(rolloff, rrc_span, sps, 'sqrt'), sps);

bits_rrc_plot  = min(ceil(time_to_plot*bit_rate*sps), length(bpsk_rrc));
chips_rrc_plot = min(ceil(time_to_plot*chip_rate*sps), length(dsss_rrc));

figure('Name','Fig 2: RRC Pulse Shaped Signals','NumberTitle','off', ...
       'Position',[120 120 900 550]);
set(gcf,'Color','w');

subplot(2,1,1);
plot((0:bits_rrc_plot-1)/Fs_pulse*1e3, bpsk_rrc(1:bits_rrc_plot), ...
    'LineWidth',1.5,'Color',[0.2 0.4 0.8]);
grid on; xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf('BPSK - RRC Shaped | Rolloff=%.2f | Bit Rate=%.1f kbps', rolloff, bit_rate/1000));

subplot(2,1,2);
plot((0:chips_rrc_plot-1)/(chip_rate*sps)*1e3, dsss_rrc(1:chips_rrc_plot), ...
    'LineWidth',1.2,'Color',[0.2 0.6 0.2]);
grid on; xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf('DSSS - RRC Shaped | Rolloff=%.2f | Chip Rate=%.2f Mcps', rolloff, chip_rate/1e6));


%% ========================================================================
%% FIGURE 3: SPECTRUM ANALYSIS --> FUNCTION CALL
%% ========================================================================

plot_frequency_domain(bpsk_waveform, DSSS, Fs_pulse, ...
                      bit_rate, chip_rate, fp, total_time);

%% ========================================================================
%% FIGURE 4: CHANNEL SIGNALS (TX, Jammer, Received DSSS)
%% ========================================================================

jammer_wave  = repelem(jammer_c, sps);
rx_dsss_wave = repelem(received_DSSS, sps);
t_chip_wave  = (0:length(received_DSSS)*sps-1) / (chip_rate * sps);

smp_plot  = min(ceil(time_to_plot*chip_rate)*sps, ...
            min(length(jammer_wave), length(rx_dsss_wave)));
bits_plot = min(ceil(time_to_plot*bit_rate*sps), length(bpsk_waveform));

figure('Name','Fig 4: Channel Signals','NumberTitle','off','Position',[150 80 1000 750]);
set(gcf,'Color','w');

subplot(3,1,1);
plot(t_waveform(1:bits_plot)*1e3, bpsk_waveform(1:bits_plot), ...
    'LineWidth',1.5,'Color',[0.2 0.4 0.8]);
grid on; ylim([-1.5 1.5]);
xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf('Transmitted DSSS (After Spreading) | PG=%d', fp));

subplot(3,1,2);
plot(t_chip_wave(1:smp_plot)*1e3, jammer_wave(1:smp_plot), ...
    'LineWidth',1.3,'Color',[0.6 0.0 0.8]);
grid on;
xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf('Narrowband CW Jammer | Aj=%.2f | fj=%.1f kHz', Aj, fj_norm*chip_rate/1000));

subplot(3,1,3);
plot(t_chip_wave(1:smp_plot)*1e3, rx_dsss_wave(1:smp_plot), ...
    'LineWidth',1.0,'Color',[0.7 0.3 0.0]);
grid on;
xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf('Received Signal (DSSS + Jammer + AWGN) | Eb/N0=%d dB', EbN0_dB));

%% ========================================================================
%% FIGURE 5: AUDIO RECOVERY COMPARISON
%% ========================================================================
orig_len  = min(5000, length(audio_norm));
recov_len = min(5000, length(audio_rx));
t_aud     = (0:orig_len-1) / Fs_audio * 1000;

figure('Name','Fig 5: Audio Recovery','NumberTitle','off','Position',[200 180 950 430]);
set(gcf,'Color','w');

plot(t_aud, audio_norm(1:orig_len), 'Color',[0.2 0.4 0.8], 'LineWidth',1.3);
hold on;
if recov_len > 0
    plot((0:recov_len-1)/Fs_audio*1000, audio_rx(1:recov_len), ...
        'Color',[0.8 0.2 0.2], 'LineWidth',1.0, 'LineStyle','--');
end
grid on;
xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf(['Chain: Voice->BCH->Scramble->Interleave->BPSK->DSSS->' ...
    'Jammer+AWGN->Despread->Demod->Deintrlv->Descramble->BCH Dec\n' ...
    'BER=%.4f%% | Eb/N0=%d dB | PG=%d'], BER*100, EbN0_dB, fp));
legend('Original Audio','Recovered Audio','Location','northeast');

%% ========================================================================
%% FIGURE 6: BER vs SNR CURVES (BPSK vs DSSS under Jamming)
%% ========================================================================

snr_range      = -5:2:20;
BER_dsss_curve = zeros(size(snr_range));
BER_bpsk_curve = zeros(size(snr_range));

seg_len = min(2000, length(m_polar));
m_sh    = m_polar(1:seg_len);
bits_sh = double(m_sh < 0);

pn_sh   = pn_code(1:seg_len*fp);
me_sh   = repelem(m_sh, fp);
me_sh   = me_sh(:).';
dsss_sh = me_sh .* pn_sh;

jam_sh = Aj * sin(2*pi*fj_norm*(0:length(dsss_sh)-1));
jam_sh = jam_sh(:).';
jam_bits_sh  = mean(reshape(jam_sh, fp, []), 1);

for k = 1:length(snr_range)
    snr_k = snr_range(k);

    % DSSS path
    rx_d = awgn_channel(dsss_sh + jam_sh, snr_k);
    [rb_d, ~] = despread_demodulate(rx_d, pn_sh, fp);
    cl = min(length(bits_sh), length(rb_d));
    BER_dsss_curve(k) = sum(bits_sh(1:cl) ~= rb_d(1:cl)) / cl;

    % BPSK path (no spreading, jammer hits full power)
    rx_b = awgn_channel(m_sh + jam_bits_sh, snr_k);
    rb_b = double(rx_b < 0);
    cl2  = min(length(bits_sh), length(rb_b));
    BER_bpsk_curve(k) = sum(bits_sh(1:cl2) ~= rb_b(1:cl2)) / cl2;
end

figure('Name','Fig 6: BER vs SNR - BPSK vs DSSS under Jamming', ...
       'NumberTitle','off','Position',[200 200 820 500]);
set(gcf,'Color','w');

semilogy(snr_range, BER_bpsk_curve + 1e-10, 'r-o', 'LineWidth',2,'MarkerSize',8);
hold on;
semilogy(snr_range, BER_dsss_curve + 1e-10, 'b-s', 'LineWidth',2,'MarkerSize',8);
grid on;
xlabel('SNR (dB)'); ylabel('BER (log scale)');
title(sprintf('BER vs SNR | BPSK vs DSSS under Jamming | Aj=%.2f | PG=%d', Aj, fp));
legend('BPSK (No Spreading - Jammer defeats it)', ...
       sprintf('DSSS (PG=%d - Jammer suppressed)', fp), ...
       'Location','northeast');
xlim([snr_range(1) snr_range(end)]);

%% ========================================================================
%% FIGURE 7: BIT-LEVEL 0/1 WAVEFORM VALIDATION 
%% ========================================================================

plot_range = 1:60;
lim_rx     = min(length(bits_rx), max(plot_range));

figure('Color','w','Name','Fig 7: Bit-Level Reconstruction (0/1 Waveform)', ...
       'Position',[150 150 1000 500]);

subplot(2,1,1);
stairs([bits_pcm(plot_range), bits_pcm(plot_range(end))], ...
    'LineWidth', 2, 'Color', [0 0.5 0]);
ylim([-0.2 1.2]); grid on;
title('1. Original Transmitted Bits (0/1 Waveform) - Before BCH Encoding');
ylabel('Logic Level'); xlabel('Bit Index');
set(gca, 'YTick', [0 1]);

subplot(2,1,2);
bits_rx_plot = [bits_rx(1:lim_rx), bits_rx(lim_rx)];
stairs(bits_rx_plot, 'LineWidth', 2, 'Color', [0.8 0 0]);
ylim([-0.2 1.2]); grid on;
title(['2. Recovered Bits (0/1 Waveform) - After Full Chain | Match: ', ...
    num2str((1-BER)*100, '%.2f'), '%  |  BER = ', num2str(BER, '%.5f')]);
ylabel('Logic Level'); xlabel('Bit Index');
set(gca, 'YTick', [0 1]);

%% ========================================================================
%% FINAL SYSTEM SUMMARY
%% ========================================================================
bw_bpsk = 2 * (bit_rate  / 1000);
bw_dsss = 2 * (chip_rate / 1000);

fprintf('\n========================================\n');
fprintf('   COMPLETE SYSTEM SUMMARY\n');
fprintf('========================================\n\n');

fprintf('--- TRANSMITTER CHAIN ---\n');
fprintf('Voice Source              : %d samples @ %.1f kHz\n', length(audio_norm), Fs_audio/1000);
fprintf('PCM Bits                  : %d\n', length(bits_pcm));
fprintf('BCH(%d,%d) Encoded       : %d bits | rate=%.3f\n', N_bch, K_bch, length(bits_bch), K_bch/N_bch);
fprintf('After Scramble+Interleave : %d bits\n', length(bits_int));
fprintf('BPSK Bit Rate             : %.1f kbps\n', bit_rate/1000);
fprintf('Processing Gain (PG)      : %d\n', fp);
fprintf('Chip Rate                 : %.2f Mcps\n', chip_rate/1e6);
fprintf('DSSS Bandwidth            : %.1f kHz\n', bw_dsss);

fprintf('\n--- CHANNEL ---\n');
fprintf('Eb/N0                     : %d dB\n', EbN0_dB);
fprintf('Jammer Type               : Narrowband CW\n');
fprintf('Jammer Amplitude          : %.2f\n', Aj);
fprintf('Jammer Frequency          : %.1f kHz\n', fj_norm*chip_rate/1000);
fprintf('Jamming Margin (PG)       : %.1f dB\n', 10*log10(fp));

fprintf('\n--- RECEIVER CHAIN ---\n');
fprintf('BCH(%d,%d) Decoded       : %d bits\n', N_bch, K_bch, length(bits_rx));
fprintf('Recovered Audio Samples   : %d\n', length(audio_rx));
fprintf('BER                       : %.6f (%.4f%%)\n', BER, BER*100);

fprintf('\n========================================\n');
fprintf('Simulation Complete \n');
fprintf('========================================\n\n');
