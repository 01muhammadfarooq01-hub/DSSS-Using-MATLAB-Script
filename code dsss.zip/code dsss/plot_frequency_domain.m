function plot_frequency_domain(bpsk_waveform, DSSS_chips, Fs_pulse, ...
                                bit_rate, chip_rate, fp, total_time)
%% ========================================================================
%% FUNCTION: plot_frequency_domain
%% ========================================================================
% PURPOSE  : BPSK aur DSSS signal ka power spectrum plot karta hai
%
% INPUTS:
%   bpsk_waveform  - BPSK signal (m_polar ko sps se repelem kiya hua)
%   DSSS_chips     - DSSS chip-level signal (1 sample per chip, bipolar)
%   Fs_pulse       - BPSK waveform Fs = bit_rate * sps
%   bit_rate       - Data bit rate (bps)
%   chip_rate      - Chip rate (bps) = bit_rate * fp
%   fp             - Processing gain
%   total_time     - Signal duration (seconds)
%
% SPECTRUM METHOD:
%   BPSK : bpsk_waveform use karo  → Fs = Fs_pulse         → null at bit_rate
%   DSSS : DSSS_chips ko andar oversample karo (sps=10)
%          → Fs = chip_rate * sps  → null at chip_rate
%   Dono ke rectangular pulse properly represent hogi → sinc spectrum milega
%% ========================================================================

    % Bandwidth (null-to-null)
    bw_bpsk = 2 * (bit_rate  / 1000);   % kHz
    bw_dsss = 2 * (chip_rate / 1000);   % kHz

    % DSSS ko andar oversample karo — sps chips per sample
    sps_spec    = 10;
    dsss_os     = repelem(DSSS_chips, sps_spec);   % rectangular pulse
    Fs_dsss     = chip_rate * sps_spec;            % correct Fs for DSSS FFT

    figure('Name','Spectrum Analysis - DSSS Spreading Effect', ...
           'NumberTitle','off','Position',[150 50 1000 700]);
    set(gcf, 'Color', 'w');

    % -------------------------------------------------------
    % --- Subplot 1: BPSK Spectrum ---
    % -------------------------------------------------------
    subplot(2,1,1);

    window_bpsk   = hamming(length(bpsk_waveform))';
    bpsk_windowed = bpsk_waveform .* window_bpsk;

    NFFT    = 2^nextpow2(length(bpsk_windowed));
    Y_bpsk  = fft(bpsk_windowed, NFFT);
    P2_bpsk = abs(Y_bpsk/NFFT);
    P1_bpsk = P2_bpsk(1:NFFT/2+1);
    P1_bpsk(2:end-1) = 2*P1_bpsk(2:end-1);

    % Frequency axis — Fs_pulse use karo
    f_bpsk = (0:(NFFT/2)) * (Fs_pulse / NFFT) / 1000;   % kHz

    plot(f_bpsk, 10*log10(P1_bpsk/max(P1_bpsk)), ...
         'LineWidth', 1.8, 'Color', [0.2 0.4 0.8]);
    grid on; hold on;

    null_freq_bpsk = bit_rate / 1000;
    y1 = ylim;
    line([null_freq_bpsk null_freq_bpsk], [y1(1) y1(2)], ...
         'Color', 'r', 'LineStyle', '--', 'LineWidth', 2);
    text(null_freq_bpsk*1.04, y1(2)-3, ...
         sprintf('Null @ %.1f kHz', null_freq_bpsk), 'Color','r','FontWeight','bold');
    line([bw_bpsk bw_bpsk], [y1(1) y1(2)], ...
         'Color', 'g', 'LineStyle', '--', 'LineWidth', 1.5);
    text(bw_bpsk*1.04, y1(1)+3, ...
         sprintf('BW: %.1f kHz', bw_bpsk), 'Color','g','FontWeight','bold');

    title('BPSK Power Spectrum (Before Spreading)');
    xlabel('Frequency (kHz)'); ylabel('Normalized Power (dB)');
    xlim([0, bw_bpsk * 1.2]);

    info_str1 = sprintf('BPSK Signal:\nBit Rate: %.1f kbps\nBandwidth: %.1f kHz\nDuration: %.2f sec', ...
                        bit_rate/1000, bw_bpsk, total_time);
    annotation('textbox', [0.15, 0.75, 0.15, 0.1], 'String', info_str1, ...
               'FitBoxToText','on','BackgroundColor','white', ...
               'EdgeColor','black','FontSize',9);

    % -------------------------------------------------------
    % --- Subplot 2: DSSS Spectrum ---
    % -------------------------------------------------------
    subplot(2,1,2);

    % Oversampled DSSS ka FFT — Fs = chip_rate * sps_spec
    window_dsss   = hamming(length(dsss_os))';
    dsss_windowed = dsss_os .* window_dsss;

    NFFT_d  = 2^nextpow2(length(dsss_windowed));
    Y_dsss  = fft(dsss_windowed, NFFT_d);
    P2_dsss = abs(Y_dsss/NFFT_d);
    P1_dsss = P2_dsss(1:NFFT_d/2+1);
    P1_dsss(2:end-1) = 2*P1_dsss(2:end-1);

    % Frequency axis — Fs_dsss = chip_rate * sps_spec
    f_dsss = (0:(NFFT_d/2)) * (Fs_dsss / NFFT_d) / 1000;   % kHz

    plot(f_dsss, 10*log10(P1_dsss/max(P1_dsss)), ...
         'LineWidth', 1.8, 'Color', [0.2 0.6 0.2]);
    grid on; hold on;

    null_freq_dsss = chip_rate / 1000;
    y2 = ylim;
    line([null_freq_dsss null_freq_dsss], [y2(1) y2(2)], ...
         'Color', 'r', 'LineStyle', '--', 'LineWidth', 2);
    text(null_freq_dsss*1.04, y2(2)-3, ...
         sprintf('Null @ %.1f kHz', null_freq_dsss), 'Color','r','FontWeight','bold');
    line([bw_dsss bw_dsss], [y2(1) y2(2)], ...
         'Color', 'g', 'LineStyle', '--', 'LineWidth', 1.5);
    text(bw_dsss*1.04, y2(1)+3, ...
         sprintf('BW: %.1f kHz', bw_dsss), 'Color','g','FontWeight','bold');

    title('DSSS Power Spectrum (After Spreading) - Showing Spectrum Spread');
    xlabel('Frequency (kHz)'); ylabel('Normalized Power (dB)');
    xlim([0, bw_dsss * 1.2]);

    info_str2 = sprintf('DSSS Signal:\nChip Rate: %.2f Mcps\nBandwidth: %.1f kHz\nProcessing Gain: %d\nBandwidth Expansion: %dx', ...
                        chip_rate/1e6, bw_dsss, fp, fp);
    annotation('textbox', [0.15, 0.25, 0.15, 0.12], 'String', info_str2, ...
               'FitBoxToText','on','BackgroundColor','white', ...
               'EdgeColor','black','FontSize',9);

end
