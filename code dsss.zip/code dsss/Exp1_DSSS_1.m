%% ========================================================================
%% DSSS BASED ANTI-JAMMING SYSTEM
%% Direct Sequence Spread Spectrum for Voice Communication
%% ========================================================================
% This program demonstrates:
% 1. Voice extraction as source data
% 2. BPSK baseband modulation (binary to bipolar)
% 3. PN sequence generation and DSSS spreading
% 4. Spectrum analysis showing spreading effect
%% ========================================================================

clear all; close all; clc;

%% ========================================================================
%% STEP 1: AUDIO READ & VOICE EXTRACTION
%% ========================================================================
fprintf('=== STEP 1: Loading Voice Data ===\n');

[audio_data, Fs_audio] = audioread('C:\Users\Rizwan Ali\Music\output2.wav'); 
audio_mono = audio_data(:, 1);

segment = audio_mono(20000:70000); 

fprintf('Audio Samples Extracted: %d\n', length(segment));
fprintf('Audio Duration: %.3f seconds\n', length(segment)/Fs_audio);
fprintf('Audio Sampling Rate: %.1f kHz\n\n', Fs_audio/1000);

%% ========================================================================
%% STEP 2: BITS GENERATION FROM VOICE
%% ========================================================================
fprintf('=== STEP 2: Converting Voice to Binary Data ===\n');

audio_8bit = uint8((segment + 1) * 127.5);
binary_matrix = de2bi(audio_8bit, 8); 
bits = reshape(binary_matrix', 1, []); 

m_polar = double((2 * bits) - 1); 

fprintf('Generated Binary Bits: %d\n', length(bits));
fprintf('Data converted to bipolar format (-1/+1)\n\n');

%% ========================================================================
%% STEP 3: TIMING & DATA RATE CALCULATION
%% ========================================================================
fprintf('=== STEP 3: Data Rate and Timing Setup ===\n');

bit_rate   = 176400;
T_bit      = 1/bit_rate; 
total_bits = length(m_polar);
total_time = total_bits * T_bit;

sps      = 100;
Fs_pulse = bit_rate * sps;

t_waveform = (0:total_bits*sps-1) / Fs_pulse;

bpsk_waveform = repelem(m_polar, sps);

fprintf('Bit Rate (Rb): %.1f kbps\n', bit_rate/1000);
fprintf('Bit Duration (Tb): %.6f ms\n', T_bit*1000);
fprintf('Total Bits: %d\n', total_bits);
fprintf('Total Signal Duration: %.3f seconds\n', total_time);
fprintf('Samples per bit: %d\n', sps);
fprintf('Waveform Sampling Rate: %.2f MHz\n\n', Fs_pulse/1e6);

%% ========================================================================
%% STEP 4: BPSK BASEBAND MODULATION DISPLAY
%% ========================================================================
fprintf('=== STEP 4: BPSK Baseband Modulation ===\n');
fprintf('Message Signal: Binary 0/1 data\n');
fprintf('BPSK Signal: Bipolar -1/+1 waveform\n');
fprintf('BPSK Symbol Rate: %.2f kbps\n\n', bit_rate/1000);

%% ========================================================================
%% STEP 5: PN SEQUENCE GENERATION & DSSS SPREADING
%% ========================================================================
fprintf('=== STEP 5: PN Sequence Generation & DSSS Spreading ===\n');

fp         = 10;
pn_length  = length(m_polar) * fp;
pn_code    = randi([0,1], 1, pn_length);

pn_code            = double(pn_code);
pn_code(pn_code == 0) = -1;

message_expanded = double(repelem(m_polar, fp));

DSSS = message_expanded .* pn_code;

pn_waveform   = repelem(pn_code, sps);
dsss_waveform = repelem(DSSS, sps);

chip_rate = bit_rate * fp;
T_chip    = 1/chip_rate;

fprintf('Processing Gain (fp): %d\n', fp);
fprintf('PN Sequence Length: %d chips\n', pn_length);
fprintf('Chip Rate (Rc): %.2f Mcps\n', chip_rate/1e6);
fprintf('Chip Duration (Tc): %.6f microseconds\n', T_chip*1e6);
fprintf('DSSS Signal Created: Message x PN Sequence\n\n');

%% ========================================================================
%% STEP 6: TIME DOMAIN VISUALIZATION  -->  FUNCTION CALL
%% ========================================================================
fprintf('=== STEP 6: Creating Time Domain Plots ===\n');

time_to_plot = 0.1;

plot_time_domain(bpsk_waveform, pn_waveform, dsss_waveform, t_waveform, ...
                 bit_rate, chip_rate, fp, total_time, total_bits, ...
                 time_to_plot, sps);

fprintf('Figure 1: Time domain plots created\n');

%% ========================================================================
%% STEP 7: FREQUENCY DOMAIN ANALYSIS  -->  FUNCTION CALL
%% ========================================================================
fprintf('=== STEP 7: Spectrum Analysis ===\n');

plot_frequency_domain(bpsk_waveform, dsss_waveform, Fs_pulse, ...
                      bit_rate, chip_rate, fp, total_time);

fprintf('Figure 2: Spectrum analysis plots created\n\n');

%% ========================================================================
%% STEP 8: DETAILED PARAMETER DISPLAY
%% ========================================================================
fprintf('========================================\n');
fprintf('     DSSS ANTI-JAMMING SYSTEM SUMMARY\n');
fprintf('========================================\n\n');

bw_bpsk = 2 * (bit_rate  / 1000);
bw_dsss = 2 * (chip_rate / 1000);

fprintf('--- Voice Source ---\n');
fprintf('Audio Samples: %d\n', length(segment));
fprintf('Audio Duration: %.3f seconds\n', length(segment)/Fs_audio);
fprintf('Audio Sampling Rate: %.1f kHz\n\n', Fs_audio/1000);

fprintf('--- Binary Data ---\n');
fprintf('Total Bits Generated: %d bits\n', total_bits);
fprintf('Data Format: Bipolar (-1/+1)\n\n');

fprintf('--- BPSK Baseband Modulation ---\n');
fprintf('Bit Rate (Rb): %.3f kbps (%.6f Mbps)\n', bit_rate/1000, bit_rate/1e6);
fprintf('Bit Duration (Tb): %.6f ms\n', T_bit*1000);
fprintf('Signal Duration: %.3f seconds\n', total_time);
fprintf('BPSK Bandwidth (Null-to-Null): %.1f kHz\n\n', bw_bpsk);

fprintf('--- PN Sequence & DSSS Spreading ---\n');
fprintf('Processing Gain (PG): %d\n', fp);
fprintf('Chip Rate (Rc): %.3f Mcps\n', chip_rate/1e6);
fprintf('Chip Duration (Tc): %.6f microseconds\n', T_chip*1e6);
fprintf('PN Sequence Length: %d chips\n', pn_length);
fprintf('DSSS Bandwidth (Null-to-Null): %.1f kHz\n', bw_dsss);
fprintf('Bandwidth Expansion Factor: %dx\n\n', fp);

fprintf('--- Spreading Effect ---\n');
fprintf('Original BPSK Bandwidth: %.1f kHz\n', bw_bpsk);
fprintf('Spread DSSS Bandwidth: %.1f kHz\n', bw_dsss);
fprintf('Spectrum Spread Ratio: %.1fx\n', bw_dsss/bw_bpsk);
fprintf('Power Reduction per Hz: %.1f dB (Processing Gain)\n', 10*log10(fp));

SNR_dB     = 10;
SNR_linear = 10^(SNR_dB/10);

C_bpsk = bw_bpsk * 1000 * log2(1 + SNR_linear);
C_dsss = bw_dsss * 1000 * log2(1 + SNR_linear);

fprintf('\n--- Shannon Capacity Analysis (SNR = %d dB) ---\n', SNR_dB);
fprintf('BPSK Channel Capacity: %.2f Mbps\n', C_bpsk/1e6);
if C_bpsk > bit_rate
    fprintf('  Result: Channel CAN support %.1f kbps\n', bit_rate/1000);
else
    fprintf('  Result: Channel CANNOT support %.1f kbps\n', bit_rate/1000);
end

fprintf('\nDSSS Channel Capacity: %.2f Mbps\n', C_dsss/1e6);
if C_dsss > bit_rate
    fprintf('  Result: Channel CAN support %.1f kbps\n', bit_rate/1000);
else
    fprintf('  Result: Channel CANNOT support %.1f kbps\n', bit_rate/1000);
end

fprintf('\n--- Anti-Jamming Benefits ---\n');
fprintf('1. Jamming Margin: %.1f dB (Processing Gain)\n', 10*log10(fp));
fprintf('2. Spectrum Spreading: %dx bandwidth expansion\n', fp);
fprintf('3. Power Spectral Density: Reduced by %.1f dB\n', 10*log10(fp));
fprintf('4. Interference Rejection: Improved by PG factor\n');

fprintf('\n========================================\n');
fprintf('Simulation Complete!\n');
fprintf('Figures Generated:\n');
fprintf('  Figure 1: Time Domain Signals (BPSK, PN, DSSS)\n');
fprintf('  Figure 2: Spectrum Analysis (BPSK vs DSSS)\n');
fprintf('========================================\n\n');
