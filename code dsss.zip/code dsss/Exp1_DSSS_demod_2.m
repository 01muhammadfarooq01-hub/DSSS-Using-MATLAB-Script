%% ========================================================================
%% DSSS BASED ANTI-JAMMING SYSTEM
%% Direct Sequence Spread Spectrum for Voice Communication
%% ========================================================================
% This program demonstrates:
% 1.  Voice extraction as source data
% 2.  BPSK baseband modulation (binary to bipolar)
% 3.  PN sequence generation and DSSS spreading
% 4.  AWGN channel (noise addition)
% 5.  Despreading (received x PN code)
% 6.  BPSK demodulation and original signal recovery
% 7.  Spectrum analysis + time domain plots
%% ========================================================================

clear all; close all; clc;

%% ========================================================================
%% STEP 1: AUDIO READ & VOICE EXTRACTION
%% ========================================================================
fprintf('=== STEP 1: Loading Voice Data ===\n');

[audio_data, Fs_audio] = audioread('C:\Users\Rizwan Ali\Music\output2.wav');
audio_mono = audio_data(:, 1);

segment = audio_mono(20000:70000);

fprintf('Audio Samples Extracted: %d\n', length(segment));
fprintf('Audio Duration: %.3f seconds\n', length(segment)/Fs_audio);
fprintf('Audio Sampling Rate: %.1f kHz\n\n', Fs_audio/1000);

%% ========================================================================
%% STEP 2: BITS GENERATION FROM VOICE
%% ========================================================================
fprintf('=== STEP 2: Converting Voice to Binary Data ===\n');

audio_8bit    = uint8((segment + 1) * 127.5);
binary_matrix = de2bi(audio_8bit, 8);
bits          = reshape(binary_matrix', 1, []);

m_polar = double((2 * bits) - 1);

fprintf('Generated Binary Bits: %d\n', length(bits));
fprintf('Data converted to bipolar format (-1/+1)\n\n');

%% ========================================================================
%% STEP 3: TIMING & DATA RATE CALCULATION
%% ========================================================================
fprintf('=== STEP 3: Data Rate and Timing Setup ===\n');

bit_rate   = 176400;
T_bit      = 1 / bit_rate;
total_bits = length(m_polar);
total_time = total_bits * T_bit;

sps      = 100;
Fs_pulse = bit_rate * sps;

t_waveform    = (0:total_bits*sps-1) / Fs_pulse;
bpsk_waveform = repelem(m_polar, sps);

fprintf('Bit Rate (Rb)             : %.1f kbps\n', bit_rate/1000);
fprintf('Bit Duration (Tb)         : %.6f ms\n', T_bit*1000);
fprintf('Total Bits                : %d\n', total_bits);
fprintf('Total Signal Duration     : %.3f seconds\n', total_time);
fprintf('Samples per bit           : %d\n', sps);
fprintf('Waveform Sampling Rate    : %.2f MHz\n\n', Fs_pulse/1e6);

%% ========================================================================
%% STEP 4: BPSK BASEBAND MODULATION DISPLAY
%% ========================================================================
fprintf('=== STEP 4: BPSK Baseband Modulation ===\n');
fprintf('Message Signal : Binary 0/1 data\n');
fprintf('BPSK Signal    : Bipolar -1/+1 waveform\n');
fprintf('BPSK Symbol Rate: %.2f kbps\n\n', bit_rate/1000);

%% ========================================================================
%% STEP 5: PN SEQUENCE GENERATION & DSSS SPREADING
%% ========================================================================
fprintf('=== STEP 5: PN Sequence Generation & DSSS Spreading ===\n');

fp        = 10;
pn_length = length(m_polar) * fp;
pn_code   = randi([0,1], 1, pn_length);

pn_code             = double(pn_code);
pn_code(pn_code==0) = -1;

message_expanded = double(repelem(m_polar, fp));

DSSS = message_expanded .* pn_code;

pn_waveform   = repelem(pn_code, sps);
dsss_waveform = repelem(DSSS, sps);

chip_rate = bit_rate * fp;
T_chip    = 1 / chip_rate;

fprintf('Processing Gain (fp)      : %d\n', fp);
fprintf('PN Sequence Length        : %d chips\n', pn_length);
fprintf('Chip Rate (Rc)            : %.2f Mcps\n', chip_rate/1e6);
fprintf('Chip Duration (Tc)        : %.6f microseconds\n', T_chip*1e6);
fprintf('DSSS Signal Created       : Message x PN Sequence\n\n');

%% ========================================================================
%% STEP 6: AWGN CHANNEL  -->  FUNCTION CALL
%% ========================================================================
fprintf('=== STEP 6: Passing Through AWGN Channel ===\n');

SNR_dB = 10;   % <-- SNR badlao yahan se (try 5, 10, 20 dB)

received_DSSS = awgn_channel(DSSS, SNR_dB);

fprintf('\n');

%% ========================================================================
%% STEP 7: DESPREADING & DEMODULATION  -->  FUNCTION CALL
%% ========================================================================
fprintf('=== STEP 7: Despreading & Demodulation (Receiver Side) ===\n');

[recovered_bits, recovered_audio] = despread_demodulate(received_DSSS, pn_code, fp);

fprintf('\n');

%% ========================================================================
%% STEP 8: BER CALCULATION
%% ========================================================================
fprintf('=== STEP 8: BER Calculation ===\n');

compare_len = min(length(bits), length(recovered_bits));
bit_errors  = sum(bits(1:compare_len) ~= recovered_bits(1:compare_len));
BER         = bit_errors / compare_len;

fprintf('Bits Compared             : %d\n', compare_len);
fprintf('Bit Errors                : %d\n', bit_errors);
fprintf('Bit Error Rate (BER)      : %.6f\n', BER);
fprintf('BER (percent)             : %.4f %%\n\n', BER*100);

%% ========================================================================
%% STEP 9: TX SIDE TIME DOMAIN PLOTS  -->  FUNCTION CALL
%% ========================================================================
fprintf('=== STEP 9: Creating Time Domain Plots ===\n');

time_to_plot = 0.1;

plot_time_domain(bpsk_waveform, pn_waveform, dsss_waveform, t_waveform, ...
                 bit_rate, chip_rate, fp, total_time, total_bits, ...
                 time_to_plot, sps);

fprintf('Figure 1: Time domain plots created (TX side)\n');

%% ========================================================================
%% STEP 10: FREQUENCY DOMAIN PLOTS  -->  FUNCTION CALL
%% ========================================================================
fprintf('=== STEP 10: Spectrum Analysis ===\n');

plot_frequency_domain(bpsk_waveform, dsss_waveform, Fs_pulse, ...
                      bit_rate, chip_rate, fp, total_time);

fprintf('Figure 2: Spectrum analysis plots created\n\n');

%% ========================================================================
%% STEP 11: RECEIVER SIDE TIME DOMAIN PLOT
%% ========================================================================
fprintf('=== STEP 11: Receiver Side Time Domain Plots ===\n');

received_waveform = repelem(received_DSSS, sps);
t_chip_waveform   = (0:length(received_DSSS)*sps-1) / (chip_rate * sps);

chips_to_plot   = min(ceil(time_to_plot * chip_rate), length(received_DSSS));
samples_rx_plot = chips_to_plot * sps;

figure('Name','Receiver Side Signals','NumberTitle','off','Position',[200 150 900 700]);
set(gcf, 'Color', 'w');

% --- Subplot 1: Received Noisy DSSS ---
subplot(3,1,1);
plot(t_chip_waveform(1:samples_rx_plot)*1e3, received_waveform(1:samples_rx_plot), ...
    'LineWidth', 1.2, 'Color', [0.7 0.3 0.0]);
grid on;
xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf('Received Noisy DSSS Signal | SNR = %d dB', SNR_dB));

% --- Subplot 2: Original Transmitted BPSK ---
bits_to_plot_rx = min(ceil(time_to_plot * bit_rate) * sps, length(bpsk_waveform));
subplot(3,1,2);
plot(t_waveform(1:bits_to_plot_rx)*1e3, bpsk_waveform(1:bits_to_plot_rx), ...
    'LineWidth', 1.5, 'Color', [0.2 0.4 0.8]);
grid on; ylim([-1.5 1.5]);
xlabel('Time (ms)'); ylabel('Amplitude');
title('Original BPSK Signal (Transmitted - Reference)');

% --- Subplot 3: Original Audio vs Recovered Audio ---
subplot(3,1,3);
orig_len  = min(5000, length(segment));
recov_len = min(5000, length(recovered_audio));
t_audio   = (0:orig_len-1) / Fs_audio * 1000;

plot(t_audio, segment(1:orig_len), 'Color', [0.2 0.4 0.8], 'LineWidth', 1.2);
hold on;
if recov_len > 0
    plot((0:recov_len-1)/Fs_audio*1000, recovered_audio(1:recov_len), ...
        'Color', [0.8 0.2 0.2], 'LineWidth', 1.0, 'LineStyle', '--');
end
grid on;
xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf('Audio Recovery | Original (Blue) vs Recovered (Red) | BER = %.4f%%', BER*100));
legend('Original Audio', 'Recovered Audio', 'Location', 'northeast');

fprintf('Figure 3: Receiver side plots created\n\n');

%% ========================================================================
%% STEP 12: COMPLETE SYSTEM SUMMARY
%% ========================================================================
bw_bpsk = 2 * (bit_rate  / 1000);
bw_dsss = 2 * (chip_rate / 1000);

fprintf('========================================\n');
fprintf('   DSSS ANTI-JAMMING SYSTEM SUMMARY\n');
fprintf('========================================\n\n');

fprintf('--- Voice Source ---\n');
fprintf('Audio Samples             : %d\n', length(segment));
fprintf('Audio Duration            : %.3f seconds\n', length(segment)/Fs_audio);
fprintf('Audio Sampling Rate       : %.1f kHz\n\n', Fs_audio/1000);

fprintf('--- Transmitter ---\n');
fprintf('Bit Rate (Rb)             : %.3f kbps\n', bit_rate/1000);
fprintf('Bit Duration (Tb)         : %.6f ms\n', T_bit*1000);
fprintf('BPSK Bandwidth            : %.1f kHz\n\n', bw_bpsk);

fprintf('--- DSSS Spreading ---\n');
fprintf('Processing Gain (PG)      : %d\n', fp);
fprintf('Chip Rate (Rc)            : %.3f Mcps\n', chip_rate/1e6);
fprintf('Chip Duration (Tc)        : %.6f us\n', T_chip*1e6);
fprintf('DSSS Bandwidth            : %.1f kHz\n', bw_dsss);
fprintf('Bandwidth Expansion       : %dx\n\n', fp);

fprintf('--- AWGN Channel ---\n');
fprintf('SNR                       : %d dB\n', SNR_dB);
fprintf('Jamming Margin (PG)       : %.1f dB\n\n', 10*log10(fp));

fprintf('--- Receiver ---\n');
fprintf('Despreading               : Received x PN Code\n');
fprintf('Decision Rule             : sign(integrated chips)\n');
fprintf('Bits Compared             : %d\n', compare_len);
fprintf('Bit Errors                : %d\n', bit_errors);
fprintf('BER                       : %.6f (%.4f%%)\n\n', BER, BER*100);

fprintf('--- Spreading Effect ---\n');
fprintf('Original BPSK Bandwidth   : %.1f kHz\n', bw_bpsk);
fprintf('Spread DSSS Bandwidth     : %.1f kHz\n', bw_dsss);
fprintf('Spectrum Spread Ratio     : %.1fx\n', bw_dsss/bw_bpsk);
fprintf('PSD Reduction             : %.1f dB\n\n', 10*log10(fp));

SNR_linear = 10^(SNR_dB/10);
C_bpsk     = bw_bpsk * 1000 * log2(1 + SNR_linear);
C_dsss     = bw_dsss * 1000 * log2(1 + SNR_linear);

fprintf('--- Shannon Capacity (SNR = %d dB) ---\n', SNR_dB);
fprintf('BPSK Channel Capacity     : %.2f Mbps\n', C_bpsk/1e6);
if C_bpsk > bit_rate
    fprintf('  Result: Channel CAN support %.1f kbps\n', bit_rate/1000);
else
    fprintf('  Result: Channel CANNOT support %.1f kbps\n', bit_rate/1000);
end
fprintf('DSSS Channel Capacity     : %.2f Mbps\n', C_dsss/1e6);
if C_dsss > bit_rate
    fprintf('  Result: Channel CAN support %.1f kbps\n', bit_rate/1000);
else
    fprintf('  Result: Channel CANNOT support %.1f kbps\n', bit_rate/1000);
end

fprintf('\n--- Anti-Jamming Benefits ---\n');
fprintf('1. Jamming Margin         : %.1f dB\n', 10*log10(fp));
fprintf('2. Spectrum Spreading     : %dx bandwidth expansion\n', fp);
fprintf('3. PSD Reduction          : %.1f dB\n', 10*log10(fp));
fprintf('4. Interference Rejection : Improved by PG factor\n');

fprintf('\n========================================\n');
fprintf('Simulation Complete!\n');
fprintf('Figures Generated:\n');
fprintf('  Figure 1 : Time Domain TX (BPSK, PN, DSSS)\n');
fprintf('  Figure 2 : Spectrum Analysis (BPSK vs DSSS)\n');
fprintf('  Figure 3 : Receiver Side (Noisy RX, Original, Recovered Audio)\n');
fprintf('========================================\n\n');
