function received_signal = awgn_channel(transmitted_signal, SNR_dB)
%% ========================================================================
%% FUNCTION: awgn_channel
%% ========================================================================
% PURPOSE  : Signal mein AWGN (Additive White Gaussian Noise) add karta hai
%
% INPUTS:
%   transmitted_signal - Chip-level DSSS signal (bipolar -1/+1)
%   SNR_dB             - Signal to Noise Ratio in dB
%
% OUTPUT:
%   received_signal    - Noisy signal (transmitted + gaussian noise)
%
% NOTE:
%   Noise chip-level pe add hoti hai (correct approach).
%   sps-level pe add karke average lena noise ko artificially cancel
%   kar deta hai — isliye chip-level hi use kiya gaya hai.
%% ========================================================================

    signal_power = mean(transmitted_signal .^ 2);
    SNR_linear   = 10^(SNR_dB / 10);
    noise_power  = signal_power / SNR_linear;
    noise        = sqrt(noise_power) * randn(1, length(transmitted_signal));

    received_signal = transmitted_signal + noise;

    fprintf('  Signal Power         : %.4f\n', signal_power);
    fprintf('  Noise Power          : %.6f\n', noise_power);
    fprintf('  Applied SNR          : %.1f dB\n', SNR_dB);

end
