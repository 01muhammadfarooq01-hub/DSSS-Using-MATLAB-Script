function pn = lfsr_pn_sequence(total_chips, poly, init_state)
%% ========================================================================
%% FUNCTION: lfsr_pn_sequence
%% ========================================================================
% PURPOSE  : LFSR (Linear Feedback Shift Register) based PN sequence
%            generate karta hai — Communications Toolbox ki zaroorat nahi
%
% INPUTS:
%   total_chips  - Kitne chips chahiye (output length)
%   poly         - Feedback polynomial (tap positions, e.g. [10 3] means x^10 + x^3 + 1)
%   init_state   - Initial register state (binary row vector, length = max tap)
%
% OUTPUT:
%   pn           - Bipolar PN sequence (-1/+1), length = total_chips
%
% EXAMPLE CALL:
%   pn = lfsr_pn_sequence(4000, [10 3], ones(1,10));
%
% NOTE:
%   - Sequence period = 2^n - 1  (n = register length)
%   - Sequence is repeated/trimmed to match total_chips
%% ========================================================================

    n          = max(poly);          % register length
    reg        = init_state(1:n);    % shift register initialize
    raw_bits   = zeros(1, total_chips);

    for i = 1:total_chips
        % Output bit = LSB of register
        raw_bits(i) = reg(end);

        % XOR feedback taps
        feedback = 0;
        for t = 1:length(poly)
            feedback = xor(feedback, reg(poly(t)));
        end

        % Shift register right, insert feedback at MSB
        reg = [feedback, reg(1:end-1)];
    end

    % Binary (0/1) to bipolar (-1/+1)
    pn = double(raw_bits);
    pn(pn == 0) = -1;

    fprintf('  LFSR Register Length : %d\n', n);
    fprintf('  LFSR Period          : %d chips\n', 2^n - 1);
    fprintf('  Generated Chips      : %d\n', total_chips);

end
