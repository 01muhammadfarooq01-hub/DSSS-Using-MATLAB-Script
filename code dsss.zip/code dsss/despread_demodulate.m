function [recovered_bits, recovered_audio] = despread_demodulate(received_signal, pn_code, fp)
%% ========================================================================
%% FUNCTION: despread_demodulate
%% ========================================================================
% PURPOSE  : Received noisy DSSS signal ko despread aur demodulate karta hai
%            aur original bits + audio waveform recover karta hai
%
% INPUTS:
%   received_signal  - AWGN channel se aayi noisy DSSS signal (chip level)
%   pn_code          - Same PN code jo transmitter ne use kiya (bipolar -1/+1)
%   fp               - Processing gain (spreading factor)
%
% OUTPUTS:
%   recovered_bits   - Demodulated binary bits (0/1)
%   recovered_audio  - Reconstructed audio samples (-1 to +1 range)
%% ========================================================================

    %% Safety check — chip count fp ka multiple hona chahiye
    assert(mod(length(received_signal), fp) == 0, ...
        'ERROR: received_signal length, fp ka exact multiple nahi hai. Chip timing mismatch!');

    %% Step 1: DESPREADING
    % Received signal ko same PN code se multiply karo
    % PN x PN = +1, isliye original BPSK signal wapis aata hai
    despread_signal = received_signal .* pn_code;

    %% Step 2: INTEGRATION per bit (combine fp chips)
    total_chips  = length(despread_signal);
    total_bits   = floor(total_chips / fp);

    despread_matrix   = reshape(despread_signal(1:total_bits*fp), fp, total_bits);
    integrated_signal = sum(despread_matrix, 1);   % fp chips ka sum = 1 bit decision variable

    %% Step 3: BPSK DECISION (threshold = 0)
    % +ve sum -> +1 -> bit 1
    % -ve sum -> -1 -> bit 0
    bpsk_decided             = sign(integrated_signal);
    bpsk_decided(bpsk_decided == 0) = 1;    % edge case

    recovered_bits = double(bpsk_decided > 0);   % bipolar to binary

    %% Step 4: AUDIO RECONSTRUCTION
    total_bytes    = floor(length(recovered_bits) / 8);
    bits_trimmed   = recovered_bits(1:total_bytes*8);
    bits_matrix    = reshape(bits_trimmed, 8, total_bytes)';

    audio_8bit_rec  = bi2de(bits_matrix);
    recovered_audio = double(audio_8bit_rec) / 127.5 - 1;

    fprintf('  Total Chips          : %d\n', total_chips);
    fprintf('  Recovered Bits       : %d\n', length(recovered_bits));
    fprintf('  Recovered Audio Samples: %d\n', length(recovered_audio));

end
