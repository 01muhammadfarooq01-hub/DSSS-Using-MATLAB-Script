%% ========================================================================
%% DSSS BASED ANTI-JAMMING SYSTEM
%% Direct Sequence Spread Spectrum for Voice Communication
%% ========================================================================
% FIXES APPLIED:
%   [1] bit_rate = Fs_audio * 8  (data rate mismatch fix)
%   [2] LFSR based PN sequence   (randi se replace, no toolbox needed)
%   [3] Jammer signal added      (anti-jamming demo: BPSK fails, DSSS survives)
%   [4] Shannon section clarified (DSSS capacity nahi badhata)
%   [5] assert check added       (chip timing verification)
%% ========================================================================

clear all; close all; clc;

%% ========================================================================
%% STEP 1: AUDIO READ & VOICE EXTRACTION
%% ========================================================================
fprintf('=== STEP 1: Loading Voice Data ===\n');

[audio_data, Fs_audio] = audioread('C:\Users\Rizwan Ali\Music\output2.wav');
audio_mono = audio_data(:, 1);

segment = audio_mono(20000:70000);

fprintf('Audio Samples Extracted  : %d\n', length(segment));
fprintf('Audio Duration           : %.3f seconds\n', length(segment)/Fs_audio);
fprintf('Audio Sampling Rate      : %.1f kHz\n\n', Fs_audio/1000);

%% ========================================================================
%% STEP 2: BITS GENERATION FROM VOICE
%% ========================================================================
fprintf('=== STEP 2: Converting Voice to Binary Data ===\n');

audio_8bit    = uint8((segment + 1) * 127.5);
binary_matrix = de2bi(audio_8bit, 8);
bits          = reshape(binary_matrix', 1, []);

m_polar = double((2 * bits) - 1);

fprintf('Generated Binary Bits    : %d\n', length(bits));
fprintf('Data converted to bipolar format (-1/+1)\n\n');

%% ========================================================================
%% STEP 3: TIMING & DATA RATE CALCULATION
%% ========================================================================
fprintf('=== STEP 3: Data Rate and Timing Setup ===\n');

% FIX [1]: bit_rate = Fs_audio * bits_per_sample
% 44100 Hz * 8 bits = 352800 bps
% Pehle 176400 tha jo half tha — time scaling error tha
bit_rate   = Fs_audio * 8;       % 352,800 bps
T_bit      = 1 / bit_rate;
total_bits = length(m_polar);
total_time = total_bits * T_bit;

sps      = 10;          % samples per symbol
          % NOTE: sps 100 se 10 kiya — bit_rate double hua to
          %       array size RAM friendly rakhne ke liye
Fs_pulse = bit_rate * sps;

t_waveform    = (0:total_bits*sps-1) / Fs_pulse;
bpsk_waveform = repelem(m_polar, sps);

fprintf('Bit Rate (Rb)            : %.1f kbps  [= Fs x 8]\n', bit_rate/1000);
fprintf('Bit Duration (Tb)        : %.6f ms\n', T_bit*1000);
fprintf('Total Bits               : %d\n', total_bits);
fprintf('Total Signal Duration    : %.3f seconds\n', total_time);
fprintf('Samples per bit          : %d\n', sps);
fprintf('Waveform Sampling Rate   : %.3f MHz\n\n', Fs_pulse/1e6);

%% ========================================================================
%% STEP 4: BPSK BASEBAND MODULATION DISPLAY
%% ========================================================================
fprintf('=== STEP 4: BPSK Baseband Modulation ===\n');
fprintf('Message Signal           : Binary 0/1 data\n');
fprintf('BPSK Signal              : Bipolar -1/+1 waveform\n');
fprintf('BPSK Symbol Rate         : %.2f kbps\n\n', bit_rate/1000);

%% ========================================================================
%% STEP 5: PN SEQUENCE GENERATION (LFSR) & DSSS SPREADING
%% ========================================================================
fprintf('=== STEP 5: LFSR PN Sequence Generation & DSSS Spreading ===\n');

fp        = 10;
pn_length = length(m_polar) * fp;

% FIX [2]: LFSR based PN sequence (randi random se replace)
% Polynomial: x^10 + x^3 + 1  (taps = [10 3])
% Period = 2^10 - 1 = 1023 chips, phir repeat hota hai
pn_poly      = [10 3];
pn_initstate = [1 0 0 1 0 1 0 1 1 0];   % non-zero initial state

fprintf('  Generating LFSR PN Sequence...\n');
pn_code = lfsr_pn_sequence(pn_length, pn_poly, pn_initstate);

message_expanded = double(repelem(m_polar, fp));

% DSSS spreading
DSSS = message_expanded .* pn_code;

% Waveforms for plotting
pn_waveform   = repelem(pn_code, sps);
dsss_waveform = repelem(DSSS, sps);

chip_rate = bit_rate * fp;
T_chip    = 1 / chip_rate;

fprintf('  Processing Gain (fp)   : %d\n', fp);
fprintf('  PN Sequence Length     : %d chips\n', pn_length);
fprintf('  Chip Rate (Rc)         : %.2f Mcps\n', chip_rate/1e6);
fprintf('  Chip Duration (Tc)     : %.6f microseconds\n', T_chip*1e6);
fprintf('  DSSS Created           : Message x LFSR-PN\n\n');

%% ========================================================================
%% STEP 6: AWGN CHANNEL (NO JAMMER)  -->  FUNCTION CALL
%% ========================================================================
fprintf('=== STEP 6: AWGN Channel (No Jammer) ===\n');

SNR_dB = 10;   % <-- SNR change karo yahan (5, 10, 20 dB try karo)

received_DSSS_clean = awgn_channel(DSSS, SNR_dB);
fprintf('\n');

%% ========================================================================
%% STEP 7: JAMMER SIGNAL GENERATION + CHANNEL WITH JAMMER
%% ========================================================================
fprintf('=== STEP 7: Jammer Signal + Channel With Jammer ===\n');

% FIX [3]: Narrowband tone jammer (single frequency)
% Jammer frequency = BPSK center pe attack karega
% Jammer power control: jammer_amplitude se badlo
jammer_amplitude = 2.0;   % 2.0 = strong jammer (BPSK ko destroy karta hai)
                           % try: 0.5 (weak), 1.0 (medium), 2.0 (strong)

% Jammer: single tone at fc = bit_rate/4 (center of BPSK band)
t_chip = (0:length(DSSS)-1) / chip_rate;
f_jammer = bit_rate / 4;   % narrowband jammer frequency
jammer_chip = jammer_amplitude * sin(2 * pi * f_jammer * t_chip);

% Channel: DSSS + jammer + AWGN
received_DSSS_jammed = awgn_channel(DSSS + jammer_chip, SNR_dB);

% BPSK alone with same jammer (to show BPSK fails)
% BPSK chip-level = m_polar (no spreading)
bpsk_chip    = m_polar;
t_bpsk_chip  = (0:length(bpsk_chip)-1) / bit_rate;
jammer_bpsk  = jammer_amplitude * sin(2 * pi * f_jammer * t_bpsk_chip);
received_BPSK_jammed = awgn_channel(bpsk_chip + jammer_bpsk, SNR_dB);

fprintf('  Jammer Type            : Narrowband tone\n');
fprintf('  Jammer Frequency       : %.2f kHz\n', f_jammer/1000);
fprintf('  Jammer Amplitude       : %.1f\n', jammer_amplitude);
fprintf('  Jammer Power           : %.4f\n\n', mean(jammer_chip.^2));

%% ========================================================================
%% STEP 8: DESPREADING & DEMODULATION  -->  FUNCTION CALL
%% ========================================================================
fprintf('=== STEP 8: Despreading & Demodulation ===\n');

% (a) Clean channel recovery
fprintf('  [Clean Channel]\n');
[recovered_bits_clean, recovered_audio_clean] = ...
    despread_demodulate(received_DSSS_clean, pn_code, fp);
fprintf('\n');

% (b) Jammed channel - DSSS recovery
fprintf('  [Jammed Channel - DSSS Receiver]\n');
[recovered_bits_jammed, recovered_audio_jammed] = ...
    despread_demodulate(received_DSSS_jammed, pn_code, fp);
fprintf('\n');

% (c) Jammed channel - BPSK only (direct decision, no despreading)
fprintf('  [Jammed Channel - BPSK Receiver]\n');
bpsk_decided_jammed              = sign(received_BPSK_jammed);
bpsk_decided_jammed(bpsk_decided_jammed == 0) = 1;
recovered_bits_bpsk_jammed       = double(bpsk_decided_jammed > 0);
fprintf('  Recovered Bits (BPSK)  : %d\n\n', length(recovered_bits_bpsk_jammed));

%% ========================================================================
%% STEP 9: BER CALCULATION (3 SCENARIOS)
%% ========================================================================
fprintf('=== STEP 9: BER Calculation ===\n');

% Scenario 1: DSSS, no jammer
len1       = min(length(bits), length(recovered_bits_clean));
errors1    = sum(bits(1:len1) ~= recovered_bits_clean(1:len1));
BER_clean  = errors1 / len1;

% Scenario 2: DSSS, with jammer
len2          = min(length(bits), length(recovered_bits_jammed));
errors2       = sum(bits(1:len2) ~= recovered_bits_jammed(1:len2));
BER_jammed    = errors2 / len2;

% Scenario 3: BPSK, with jammer
len3              = min(length(bits), length(recovered_bits_bpsk_jammed));
errors3           = sum(bits(1:len3) ~= recovered_bits_bpsk_jammed(1:len3));
BER_bpsk_jammed   = errors3 / len3;

fprintf('  DSSS  (No Jammer)  BER : %.6f  (%.4f%%)\n', BER_clean,       BER_clean*100);
fprintf('  DSSS  (Jammed)     BER : %.6f  (%.4f%%)\n', BER_jammed,      BER_jammed*100);
fprintf('  BPSK  (Jammed)     BER : %.6f  (%.4f%%)\n', BER_bpsk_jammed, BER_bpsk_jammed*100);
fprintf('\n  --> DSSS survives jamming, BPSK fails. This is anti-jamming gain.\n\n');

%% ========================================================================
%% STEP 10: TX SIDE TIME DOMAIN PLOTS  -->  FUNCTION CALL
%% ========================================================================
fprintf('=== STEP 10: TX Side Time Domain Plots ===\n');

time_to_plot = 0.05;

plot_time_domain(bpsk_waveform, pn_waveform, dsss_waveform, t_waveform, ...
                 bit_rate, chip_rate, fp, total_time, total_bits, ...
                 time_to_plot, sps);

fprintf('Figure 1: TX time domain plots created\n');

%% ========================================================================
%% STEP 11: FREQUENCY DOMAIN PLOTS  -->  FUNCTION CALL
%% ========================================================================
fprintf('=== STEP 11: Spectrum Analysis ===\n');

plot_frequency_domain(bpsk_waveform, DSSS, Fs_pulse, ...
                      bit_rate, chip_rate, fp, total_time);

fprintf('Figure 2: Spectrum plots created\n\n');

%% ========================================================================
%% STEP 12: RECEIVER SIDE TIME DOMAIN
%% ========================================================================
fprintf('=== STEP 12: Receiver Side Plots ===\n');

t_chip_vec  = (0:length(received_DSSS_clean)-1) / chip_rate;
chips_show  = min(ceil(time_to_plot * chip_rate), length(received_DSSS_clean));

figure('Name','Receiver Side Signals','NumberTitle','off','Position',[200 150 900 700]);
set(gcf, 'Color', 'w');

% Subplot 1: Received noisy DSSS (no jammer)
subplot(3,1,1);
plot(t_chip_vec(1:chips_show)*1e3, received_DSSS_clean(1:chips_show), ...
    'LineWidth', 1.0, 'Color', [0.7 0.3 0.0]);
grid on;
xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf('Received DSSS Signal (AWGN only) | SNR = %d dB', SNR_dB));

% Subplot 2: Original BPSK reference
bits_show = min(ceil(time_to_plot * bit_rate) * sps, length(bpsk_waveform));
subplot(3,1,2);
plot(t_waveform(1:bits_show)*1e3, bpsk_waveform(1:bits_show), ...
    'LineWidth', 1.5, 'Color', [0.2 0.4 0.8]);
grid on; ylim([-1.5 1.5]);
xlabel('Time (ms)'); ylabel('Amplitude');
title('Original BPSK Signal (Transmitted Reference)');

% Subplot 3: Audio recovery comparison
subplot(3,1,3);
orig_len  = min(3000, length(segment));
recov_len = min(3000, length(recovered_audio_clean));
t_aud     = (0:orig_len-1) / Fs_audio * 1000;

plot(t_aud, segment(1:orig_len), 'Color', [0.2 0.4 0.8], 'LineWidth', 1.2);
hold on;
if recov_len > 0
    plot((0:recov_len-1)/Fs_audio*1000, recovered_audio_clean(1:recov_len), ...
        'Color', [0.8 0.2 0.2], 'LineWidth', 1.0, 'LineStyle', '--');
end
grid on;
xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf('Audio Recovery (No Jammer) | BER = %.4f%%', BER_clean*100));
legend('Original', 'Recovered', 'Location', 'northeast');

fprintf('Figure 3: Receiver side plots created\n\n');

%% ========================================================================
%% STEP 13: JAMMER EFFECT COMPARISON PLOT (KEY FIGURE)
%% ========================================================================
fprintf('=== STEP 13: Anti-Jamming Comparison Plot ===\n');

% Waveform level jammer (for plotting only)
jammer_waveform = repelem(jammer_chip, sps);
t_dsss_wav      = (0:length(dsss_waveform)-1) / Fs_pulse;
jammer_show     = min(ceil(time_to_plot * Fs_pulse), length(jammer_waveform));
dsss_show       = min(ceil(time_to_plot * Fs_pulse), length(dsss_waveform));
bpsk_show_j     = min(ceil(time_to_plot * bit_rate) * sps, length(bpsk_waveform));

figure('Name','Anti-Jamming: BPSK vs DSSS','NumberTitle','off','Position',[250 100 1000 800]);
set(gcf, 'Color', 'w');

% Row 1: Jammer signal
subplot(4,1,1);
plot(t_dsss_wav(1:jammer_show)*1e3, jammer_waveform(1:jammer_show), ...
    'LineWidth', 1.2, 'Color', [0.6 0.0 0.6]);
grid on;
xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf('Jammer Signal (Narrowband Tone @ %.1f kHz) | Amplitude = %.1f', ...
    f_jammer/1000, jammer_amplitude));
ylim([-jammer_amplitude*1.3 jammer_amplitude*1.3]);

% Row 2: DSSS + Jammer received
subplot(4,1,2);
dsss_jammed_wav = repelem(received_DSSS_jammed, sps);
dsss_jam_show   = min(ceil(time_to_plot * Fs_pulse), length(dsss_jammed_wav));
plot(t_dsss_wav(1:dsss_jam_show)*1e3, dsss_jammed_wav(1:dsss_jam_show), ...
    'LineWidth', 1.0, 'Color', [0.7 0.3 0.0]);
grid on;
xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf('DSSS Received (With Jammer + AWGN) | Recovered BER = %.4f%%', BER_jammed*100));

% Row 3: BPSK + Jammer received
subplot(4,1,3);
bpsk_jammed_wav = repelem(received_BPSK_jammed, sps);
bpsk_jam_show   = min(ceil(time_to_plot * bit_rate) * sps, length(bpsk_jammed_wav));
plot(t_waveform(1:bpsk_jam_show)*1e3, bpsk_jammed_wav(1:bpsk_jam_show), ...
    'LineWidth', 1.0, 'Color', [0.9 0.1 0.1]);
grid on;
xlabel('Time (ms)'); ylabel('Amplitude');
title(sprintf('BPSK Received (With Jammer + AWGN) | BER = %.4f%%', BER_bpsk_jammed*100));

% Row 4: BER Comparison Bar Chart
% MATLAB 2016 compatible: teen alag bar() calls with hold on
subplot(4,1,4);
ber_vals = [BER_clean, BER_jammed, BER_bpsk_jammed] * 100;

b1 = bar(1, ber_vals(1), 0.5);  set(b1, 'FaceColor', [0.2 0.6 0.2]);
hold on;
b2 = bar(2, ber_vals(2), 0.5);  set(b2, 'FaceColor', [0.2 0.4 0.8]);
b3 = bar(3, ber_vals(3), 0.5);  set(b3, 'FaceColor', [0.9 0.1 0.1]);

set(gca, 'XTick', [1 2 3], ...
         'XTickLabel', {'DSSS (No Jammer)', 'DSSS (Jammed)', 'BPSK (Jammed)'});
ylabel('BER (%)');
title('Anti-Jamming Performance Comparison');
grid on;
y_offset = max(ber_vals) * 0.03 + 0.01;
for k = 1:3
    text(k, ber_vals(k) + y_offset, sprintf('%.4f%%', ber_vals(k)), ...
        'HorizontalAlignment', 'center', 'FontWeight', 'bold', 'FontSize', 9);
end

fprintf('Figure 4: Anti-jamming comparison plot created\n\n');

%% ========================================================================
%% STEP 14: COMPLETE SYSTEM SUMMARY
%% ========================================================================
bw_bpsk = 2 * (bit_rate  / 1000);
bw_dsss = 2 * (chip_rate / 1000);

fprintf('========================================\n');
fprintf('   DSSS ANTI-JAMMING SYSTEM SUMMARY\n');
fprintf('========================================\n\n');

fprintf('--- Voice Source ---\n');
fprintf('Audio Samples            : %d\n', length(segment));
fprintf('Audio Duration           : %.3f seconds\n', length(segment)/Fs_audio);
fprintf('Audio Sampling Rate      : %.1f kHz\n\n', Fs_audio/1000);

fprintf('--- Transmitter ---\n');
fprintf('Bit Rate (Rb)            : %.3f kbps  [= Fs x 8, FIXED]\n', bit_rate/1000);
fprintf('Bit Duration (Tb)        : %.6f ms\n', T_bit*1000);
fprintf('BPSK Bandwidth           : %.1f kHz\n\n', bw_bpsk);

fprintf('--- DSSS Spreading ---\n');
fprintf('PN Type                  : LFSR  [x^10 + x^3 + 1]\n');
fprintf('LFSR Period              : %d chips\n', 2^10 - 1);
fprintf('Processing Gain (PG)     : %d\n', fp);
fprintf('Chip Rate (Rc)           : %.3f Mcps\n', chip_rate/1e6);
fprintf('DSSS Bandwidth           : %.1f kHz\n', bw_dsss);
fprintf('Bandwidth Expansion      : %dx\n\n', fp);

fprintf('--- AWGN Channel ---\n');
fprintf('SNR                      : %d dB\n', SNR_dB);
fprintf('Jammer Type              : Narrowband tone @ %.1f kHz\n', f_jammer/1000);
fprintf('Jammer Amplitude         : %.1f\n\n', jammer_amplitude);

fprintf('--- BER Results ---\n');
fprintf('DSSS  (No Jammer)  BER   : %.6f  (%.4f%%)\n', BER_clean,       BER_clean*100);
fprintf('DSSS  (Jammed)     BER   : %.6f  (%.4f%%)\n', BER_jammed,      BER_jammed*100);
fprintf('BPSK  (Jammed)     BER   : %.6f  (%.4f%%)\n', BER_bpsk_jammed, BER_bpsk_jammed*100);

fprintf('\n--- Spreading Effect ---\n');
fprintf('Original BPSK Bandwidth  : %.1f kHz\n', bw_bpsk);
fprintf('Spread DSSS Bandwidth    : %.1f kHz\n', bw_dsss);
fprintf('Spectrum Spread Ratio    : %.1fx\n', bw_dsss/bw_bpsk);
fprintf('PSD Reduction            : %.1f dB\n\n', 10*log10(fp));

% FIX [4]: Shannon section — clarified, no misleading comparison
fprintf('--- Shannon Capacity Note ---\n');
fprintf('DSSS does NOT increase channel capacity.\n');
fprintf('Shannon capacity depends on bandwidth x log2(1+SNR).\n');
fprintf('DSSS widens bandwidth but reduces SNR per Hz proportionally.\n');
fprintf('Net capacity = same. What DSSS improves is JAMMING TOLERANCE,\n');
fprintf('not raw throughput. This is the correct interpretation.\n\n');

fprintf('--- Anti-Jamming Benefits ---\n');
fprintf('1. Jamming Margin        : %.1f dB  (= 10*log10(PG))\n', 10*log10(fp));
fprintf('2. Spectrum Spreading    : %dx bandwidth expansion\n', fp);
fprintf('3. PSD Reduction         : %.1f dB\n', 10*log10(fp));
fprintf('4. Jammer is despread    : Narrowband jammer becomes wideband noise\n');
fprintf('5. BPSK BER under jammer : %.2f%%  -->  unusable\n', BER_bpsk_jammed*100);
fprintf('6. DSSS BER under jammer : %.4f%%  -->  recoverable\n', BER_jammed*100);

fprintf('\n========================================\n');
fprintf('Simulation Complete!\n');
fprintf('Figures Generated:\n');
fprintf('  Figure 1 : TX Time Domain (BPSK, PN, DSSS)\n');
fprintf('  Figure 2 : Spectrum Analysis (BPSK vs DSSS)\n');
fprintf('  Figure 3 : RX Side (Received, Original, Recovered Audio)\n');
fprintf('  Figure 4 : Anti-Jamming Comparison (Jammer + BER Bar Chart)\n');
fprintf('========================================\n\n');
